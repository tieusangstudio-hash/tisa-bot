"""Đẩy lead và tự lấy tin nhắn gốc từ TISA BOT. Không ghi khóa vào cấu hình plugin."""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path

def _config_file(ctx):
    return Path(ctx.data_dir) / "connection.json"


def _secret_file():
    return Path(os.environ.get("TISA_CRM_CONFIG_DIR", str(Path.home() / ".config/tisa-crm"))) / "chatbot.env"


def _credentials(ctx):
    cfg = json.loads(_config_file(ctx).read_text())
    values = dict(line.split("=", 1) for line in _secret_file().read_text().splitlines() if "=" in line)
    if values.get("CRM_URL", "").rstrip("/") != cfg["crm_url"]:
        raise ValueError("URL trong file bí mật khác URL đã nối. Chạy bootstrap đúng CRM rồi nối lại.")
    key = values.get("CRM_CHATBOT_KEY", "").strip()
    if not key:
        raise ValueError("Thiếu CRM_CHATBOT_KEY. Chạy bootstrap --chatbot-key.")
    return cfg["crm_url"] + "/api/chatbot-leads", key


def _connect(args, ctx):
    from urllib.parse import urlsplit
    url = str(args.get("crm_url", "")).strip().rstrip("/")
    parsed = urlsplit(url)
    if (parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname in ("localhost", "127.0.0.1"))) or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path:
        return "LỖI: Cần URL gốc HTTPS của CRM hoặc HTTP localhost để thử trên máy."
    try:
        values = dict(line.split("=", 1) for line in _secret_file().read_text().splitlines() if "=" in line)
        if not values.get("CRM_CHATBOT_KEY"):
            return "LỖI: Thiếu khóa. Chạy bootstrap --chatbot-key trước."
        if values.get("CRM_URL", "").rstrip("/") != url:
            return "LỖI: File bí mật thuộc CRM khác. Chạy bootstrap đúng địa chỉ CRM."
        f = _config_file(ctx)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps({"crm_url": url}, ensure_ascii=False))
        f.chmod(0o600)
        return "Đã lưu cấu hình. " + _status({}, ctx)
    except OSError:
        return "LỖI: Chưa có file chatbot.env. Chạy bootstrap --chatbot-key trước."


def _status(args, ctx):
    try:
        url, key = _credentials(ctx)
    except (OSError, ValueError, KeyError):
        return "LỖI: Thiếu cấu hình hoặc file khóa không khớp. Chạy bootstrap --chatbot-key rồi crm_chatbot_connect."
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + key, "User-Agent": "TISA-BOT/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.load(r)
            if not data.get("ok") or not isinstance(data.get("leads"), list):
                return "LỖI: CRM trả dữ liệu không đúng API."
            return "OK: Đã nối CRM, GET HTTP %s. Không hiển thị khóa hoặc dữ liệu khách." % r.status
    except urllib.error.HTTPError as e:
        return "LỖI HTTP %s: Kiểm tra URL, khóa và cấu hình API CRM." % e.code
    except Exception:
        return "LỖI: Không kết nối được CRM. Kiểm tra CRM đang chạy và mạng."


def _conversation_db():
    # Resolve the running server module, independently of the installed pack location.
    import importlib.util
    override = os.environ.get("TISA_CUSTOMER_DB")
    if override:
        return Path(override)
    spec = importlib.util.find_spec("plugins_host")
    if spec and spec.origin:
        return Path(spec.origin).resolve().parent / "customer_conversations.sqlite3"
    return None

_FIELDS = ["channel", "external_id", "name", "phone", "email", "interest", "concerns", "disc", "strategy", "summary", "note"]
_MAX_TR = 50000


def _fmt_ts(ts) -> str:
    import datetime
    try:
        tz = datetime.timezone(datetime.timedelta(hours=7))
        return datetime.datetime.fromtimestamp(float(ts), tz).strftime("%d/%m/%Y %H:%M")
    except Exception:  # noqa: BLE001
        return ""


def _auto_transcript(args: dict, phone: str):
    """Tu lay toan van hoi thoai tu kho TISA BOT: theo chat_id cua luot, roi external_id, roi SDT."""
    import sqlite3
    db_path = _conversation_db()
    if not db_path or not db_path.exists():
        return None
    chat_ids = []
    try:
        import turn_context
        turn = turn_context.current() or {}
        if turn.get("chat_id") and not turn.get("la_chu"):
            chat_ids.append(str(turn["chat_id"]))
    except Exception:  # noqa: BLE001
        pass
    if args.get("external_id"):
        chat_ids.append(str(args["external_id"]).strip())
    try:
        db = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=5)
        conv = None
        for cid in chat_ids:
            r = db.execute("select id from conversations where external_chat_id=? order by last_message_at desc limit 1", (cid,)).fetchone()
            if r:
                conv = r[0]
                break
        if conv is None and phone:
            r = db.execute(
                "select c.id from conversations c join customers u on u.id=c.customer_id where u.phone=? "
                "order by c.last_message_at desc limit 1", (phone,)).fetchone()
            if not r:
                r = db.execute(
                    "select conversation_id from messages where sender_type='customer' and "
                    "replace(replace(replace(text,' ',''),'.',''),'-','') like ? order by created_at desc limit 1",
                    ("%" + phone[1:] + "%",)).fetchone()
            conv = r[0] if r else None
        if conv is None:
            return None
        rows = db.execute("select sender_type,text,created_at,message_type from messages where conversation_id=? "
                          "order by created_at,id", (conv,)).fetchall()
        db.close()
    except Exception:  # noqa: BLE001
        return None
    items = []
    for st, txt, ts, mt in rows:
        txt = (txt or "").replace("[TACH_TIN]", "\n").strip() or ("[%s]" % (mt or "Dinh kem"))
        items.append({"from": "Khách" if st == "customer" else "Page", "text": txt[:4000], "time": _fmt_ts(ts)})
    while items and len(json.dumps(items, ensure_ascii=False).encode()) > _MAX_TR:
        items.pop(0)
    return items or None


def _phone(p: str) -> str:
    d = re.sub(r"\D", "", p or "")
    if d.startswith("84") and len(d) == 11:
        d = "0" + d[2:]
    return d


def _push(args: dict, ctx) -> str:
    body = {k: str(args.get(k) or "").strip() for k in _FIELDS if args.get(k)}
    if "phone" in body:
        body["phone"] = _phone(body["phone"])
        if not re.fullmatch(r"0\d{9}", body["phone"]):
            return "LOI: so dien thoai khong hop le (can 10 so bat dau bang 0). Hoi lai khach, chua gui."
    if not body.get("name") or not (body.get("phone") or body.get("email")):
        return "LOI: can ten va (SDT hoac email). Chua gui."
    auto = _auto_transcript(args, body.get("phone", ""))
    if auto:
        body["transcript"] = auto
    elif args.get("transcript") is not None:
        transcript = args["transcript"]
        if not isinstance(transcript, (str, list)):
            return "LỖI: transcript cần chuỗi hoặc mảng tin nhắn."
        if len(json.dumps(transcript, ensure_ascii=False).encode()) > _MAX_TR:
            return "LỖI: Tin nhắn quá dài."
        body["transcript"] = transcript
    pot = args.get("potential")
    if type(pot) is not int or pot not in (1, 2, 3, 4):
        return "LỖI: Thiếu potential số nguyên 1-4. Tự đánh giá rồi gọi lại."
    body["potential"] = pot
    if args.get("potential_reason"):
        body["potential_reason"] = str(args["potential_reason"]).strip()[:2000]
    try:
        url, token = _credentials(ctx)
    except (OSError, ValueError, KeyError):
        return "LỖI: Chưa nối CRM hoặc thiếu khóa. Chạy crm_chatbot_connect rồi crm_chatbot_status."
    req = urllib.request.Request(url, data=json.dumps(body, ensure_ascii=False).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "Authorization": "Bearer " + token, "User-Agent": "TISA-BOT/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return "OK HTTP %s: %s" % (r.status, r.read(500).decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        return "LOI HTTP %s: %s" % (e.code, e.read(300).decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        return "LOI ket noi: %s" % e


def register(ctx):
    ctx.register_tool(name="crm_chatbot_connect", description="Nối CRM, tự đọc khóa do bootstrap tạo trên máy. Không nhận khóa từ chat.", handler=_connect, min_mode="full", schema={"type":"object","properties":{"crm_url":{"type":"string"}},"required":["crm_url"]})
    ctx.register_tool(name="crm_chatbot_status", description="Kiểm cấu hình và GET thử API CRM, không lộ dữ liệu khách hay khóa.", handler=_status, min_mode="readonly", schema={"type":"object","properties":{}})
    s = lambda d: {"type": "string", "description": d}
    ctx.register_tool(
        name="crm_push_lead",
        description=("Goi NGAY khi khach tren Zalo/Facebook da de lai ten va SDT hoac email: gui lead vao muc Data Zalo / FB "
                     "cua CRM của doanh nghiệp. Kem tom tat hoi thoai, san pham quan tam, van de lo lang, nhom DISC (D/I/S/C + ly do) "
                     "va goi y chien luoc chot sale. BAT BUOC tu danh gia potential (muc tiem nang 1-4) dua tren hoi thoai, sale khong danh gia: "
                     "4 Rat nong = hoi gia/lich/cach dong tien, san sang chot hoac da coc; 3 Nong = nhu cau ro, dang can nhac (thoi gian, gia, gia dinh); "
                     "2 Am = quan tam, con tim hieu, tra loi it; 1 Lanh = hoi qua, chua co nhu cau ro hoac im lang. Kem potential_reason 1 cau dan chung tu hoi thoai. Goi lai khi co them thong tin: he thong cap nhat theo SDT, khong tao trung. "
                     "Khong noi voi khach la da luu he thong."),
        handler=_push, min_mode="full",
        schema={"type": "object", "properties": {
            "channel": {"type": "string", "enum": ["zalo", "facebook", "khac"]},
            "external_id": s("id hoi thoai/thread cua khach"),
            "name": s("ten khach"), "phone": s("so dien thoai"), "email": s("email"),
            "interest": s("san pham/khoa hoc khach quan tam"),
            "concerns": s("van de khach dang lo lang, phan doi"),
            "disc": s("D, I, S hoac C kem 1 cau ly do"),
            "strategy": s("goi y chien luoc tu van chot sale cho nguoi goi lai"),
            "summary": s("tom tat toan bo cuoc tro chuyen"),
            "transcript": {"description":"Tự lấy tin nhắn gốc nếu có. Có thể nhận chuỗi hoặc mảng {from,text,time} khi kiểm thử.","oneOf":[{"type":"string"},{"type":"array","items":{"type":"object","properties":{"from":{"type":"string"},"text":{"type":"string"},"time":{"type":"string"}},"required":["from","text"]}}]},
            "note": s("ghi chu them"),
            "potential": {"type": "integer", "enum": [1, 2, 3, 4], "description": "TISA BOT tu danh gia muc tiem nang: 4 Rat nong, 3 Nong, 2 Am, 1 Lanh"},
            "potential_reason": s("1 cau ly do danh gia, dan chung tu hoi thoai")},
            "required": ["channel", "name", "summary", "potential"]},
    )
