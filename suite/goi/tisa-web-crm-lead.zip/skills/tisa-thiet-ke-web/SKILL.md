---
name: tisa-thiet-ke-web
description: Làm giao diện Lead Page, Sale Page, trang cảm ơn và trang chủ CRM đẹp, chuyên nghiệp, đúng ngành, chạy tốt trên điện thoại. Có sẵn 8 chủ đề màu và chữ theo ngành, hiệu ứng nhẹ, bộ biểu tượng, script gắn giao diện và script soát lỗi trước khi đăng. Dùng khi muốn làm đẹp, đổi phong cách, nâng cấp giao diện, chọn màu, chọn phông, thêm ảnh, sửa lỗi hiển thị trên điện thoại, hoặc soát trang trước khi đăng.
group: Website
---

# Thiết kế giao diện web chuyên nghiệp

Việc của bạn: biến trang đang chạy được thành trang **khách nhìn vào là tin**, đúng ngành, gọn, nhanh, dễ bấm trên điện thoại. Bạn là người dựng giao diện, **không đổi lời hứa, giá, cam kết, form hay cách nối CRM** (phần đó thuộc skill `tisa-web-crm-lead`).

Gọi người dùng là "anh chị", xưng "em". Không dùng ký tự gạch dài. Không bắt họ gõ lệnh. Thứ tự: **Hiểu, Chọn hướng, Gắn giao diện, Nâng bố cục, Ảnh và biểu tượng, Soát, Cho xem.**

## Nguồn gốc nguyên tắc

Chắt lọc, viết lại theo ngữ cảnh doanh nghiệp Việt, từ: WCAG 2.2 (độ tương phản, vùng bấm, phím tắt); Refactoring UI (Wathan, Schoger: thứ bậc, khoảng trắng, bóng, màu); Don't Make Me Think (Krug: khách quét chứ không đọc); Laws of UX (Yablonski: Fitts, Hick, Von Restorff); Core Web Vitals của Google (tốc độ, ổn định bố cục); hướng dẫn thiết kế iOS HIG và Material về vùng chạm 44 đến 48px. Công thức viết chữ nằm ở skill `tisa-web-crm-lead`, không lặp ở đây.

## Tệp đi kèm (thư mục chứa SKILL.md này gọi là `<skill>`)

Không biết đường dẫn thì chạy: `find ~ -path "*skills/tisa-thiet-ke-web/SKILL.md" 2>/dev/null | head -1`.

| Tệp | Dùng để |
|---|---|
| `scripts/ap-dung-giao-dien.mjs` | Gắn hoặc đổi chủ đề, gỡ bỏ. Chạy lại an toàn |
| `scripts/soat-trang.mjs` | Soát lỗi tự động trước khi cho xem hoặc đăng |
| `assets/chu-de.css`, `nang-cap.css`, `nang-cap.js`, `icons.svg` | Giao diện, hiệu ứng, biểu tượng (script tự sao vào `lead/nang-cap/`) |
| `references/huong-tham-my.md` | Chọn chủ đề, màu, phông; luật nhận diện thương hiệu riêng |
| `references/bo-cuc-theo-khoi.md` | Mẫu HTML nâng từng khối: dải tin cậy, thẻ có biểu tượng, bảng giá, so sánh |
| `references/anh-va-bieu-tuong.md` | Tìm, tạo, nén ảnh; lời nhắc tạo ảnh theo ngành; biểu tượng |
| `references/chuyen-dong-va-chi-tiet.md` | Hiệu ứng nào nên, nào không; bóng, bo góc, trạng thái |
| `references/soat-chat-luong.md` | Danh sách soát bằng mắt: 3 cỡ màn hình, tốc độ, SEO, truy cập |
| `references/crm-giao-dien.md` | Làm đẹp phần CRM mà không phá logic |

## Bước 1. Hiểu (hỏi tối đa 4 câu, mỗi lượt một câu)

Đã có đủ từ lúc dựng bằng `tisa-web-crm-lead` (ngành, khách, màu, logo) thì **không hỏi lại**, chỉ hỏi phần còn thiếu. Mỗi câu có Gợi ý, Ví dụ và câu nhắc: "Nếu chưa có thì anh chị cứ bỏ qua, em sẽ chọn giúp, mình chỉnh sau."

1. Khách của anh chị là ai, họ nhìn trang trên điện thoại hay máy tính? (thường: điện thoại, đến từ Facebook, TikTok, Zalo)
2. Muốn khách cảm thấy gì khi vào trang: tin cậy chuyên gia, ấm áp gần gũi, sang trọng, trẻ trung, mạnh mẽ vững chãi?
3. Đã có logo, màu, ảnh thật (công trình, sản phẩm, đội ngũ) chưa? Anh chị thích trang nào làm mẫu?
4. Có trang nào của đối thủ anh chị không muốn giống?

Chưa trả lời được: chọn theo bảng ngành ở `references/huong-tham-my.md`, ghi rõ "chọn giúp".

## Bước 2. Chọn hướng và gắn giao diện

1. Chọn **một** chủ đề: `node <skill>/scripts/ap-dung-giao-dien.mjs --danh-sach`. Có màu thương hiệu thật của anh chị thì **màu thật thắng**: làm theo mục "Thương hiệu riêng" trong `references/huong-tham-my.md`, không ép chủ đề.
2. Gắn: `node <skill>/scripts/ap-dung-giao-dien.mjs --thu-muc <lead> --chu-de <id>` (`<lead>` là thư mục có `index.html`, thường `~/Documents/TISA-CRM/lead`). Script gắn cả Lead Page, Sale Page, trang cảm ơn, thêm phông, màu thanh trình duyệt, thẻ chia sẻ Zalo và Facebook. Chạy lại để đổi chủ đề. `--go` để gỡ.
3. Số Zalo, số gọi **thật** của anh chị có rồi mới thêm `data-zalo="0909…" data-goi="0909…"` vào thẻ `<body>` để hiện nút nổi. Không có số thì không thêm, không bịa.
4. Mở trang xem ngay (bước 5) trước khi làm tiếp.

## Bước 3. Nâng bố cục từng khối

Giữ nguyên khối, chữ, form; chỉ nâng cách trình bày theo `references/bo-cuc-theo-khoi.md`. Làm theo thứ tự tác dụng lớn nhất:

1. **Màn hình đầu** (quyết định khách ở lại hay thoát trong 5 giây): tiêu đề nói được kết quả, một nút chính, form nhìn thấy ngay, không có gì cạnh tranh sự chú ý. Thêm dải tin cậy phía dưới nếu có điều **thật** để nói (giấy phép, số năm, bảo hành, khu vực phục vụ).
2. **Bằng chứng**: ảnh thật đứng trước, khung đẹp sau. Chưa có ảnh thật thì giữ ô viền đứt, không dùng ảnh người mẫu nước ngoài, không dùng cảm nhận bịa.
3. **Thẻ lợi ích**: thêm biểu tượng, một ý một thẻ, câu ngắn.
4. **Giá và gói**: nổi bật một gói, làm rõ cái khách được, cái khách không phải lo.
5. **Điện thoại**: kiểm tra riêng ở 390px. Đây là nơi 80% khách của anh chị đang nhìn.

## Bước 4. Ảnh và biểu tượng

Làm theo `references/anh-va-bieu-tuong.md`. Ngắn gọn: ảnh thật của chủ trước; chưa có thì tạo ảnh minh họa bằng công cụ có sẵn (không chữ trong ảnh, không khuôn mặt người thật); nén dưới 300 KB; mọi ảnh có `alt`, `width`, `height`. Biểu tượng dùng bộ `icons.svg`, **không dùng emoji làm biểu tượng** trên trang bán hàng.

## Bước 5. Soát và cho xem

1. `node <skill>/scripts/soat-trang.mjs --thu-muc <lead>`. Sửa hết LỖI, đọc kỹ CẢNH BÁO. Trước khi đăng thật thêm `--dang` (lúc đó chữ "(mẫu)", noindex, địa chỉ localhost đều thành LỖI).
2. **Nhìn bằng mắt** theo `references/soat-chat-luong.md`: chụp ở 390px, 768px, 1280px (dùng trình duyệt TISA hoặc công cụ chụp có sẵn). Script không thay được bước này.
3. Gửi cho anh chị: link ba trang, ảnh chụp điện thoại và máy tính, **một đoạn ngắn nói đã chọn gì và vì sao** (chủ đề, phông, màu nhấn). Kèm danh sách chỗ còn giả định.
4. Ghi lại vào `<lead>/THIET-KE.md` (chủ đề, phông, màu thương hiệu, ai sửa khi nào) để lần sau sửa vẫn nhất quán.
5. Kết thúc bằng đúng câu: **"Anh chị muốn điều chỉnh, chỉnh sửa gì không, cứ báo em."**

## Luật cứng

- **Không đổi** thuộc tính form (`id="lead-form"`, `name`, `phone`, `course`, `website`, `consent`, `data-page`), `lead-config.js`, giá, cam kết, điều khoản. Không thêm đếm ngược, số chỗ, "đã có N khách" khi chưa có số thật.
- **Độ đọc được là luật, không phải sở thích:** chữ thường tối thiểu 4.5:1 với nền, chữ to 3:1, vùng bấm tối thiểu 44px, cỡ chữ ô nhập 16px trở lên (iPhone tự phóng to nếu nhỏ hơn).
- Một màu chủ đạo, một màu nhấn, nền trung tính. Tối đa hai họ phông. Tối đa một hiệu ứng chuyển động có chủ đích cho mỗi khối.
- Trang phải nhanh: tổng ảnh ban đầu dưới 1 MB, không thư viện nặng, không video tự phát âm thanh, không popup chặn nội dung.
- Không sao chép nguyên trang của người khác (bố cục, chữ, ảnh, logo). Học cách làm, không lấy bài làm.
- Khách hàng yêu cầu điều trái luật trên: nói rõ vì sao và đề xuất cách thật hơn, không làm lén.
- Chưa được anh chị đồng ý thì **không xuất bản, không tốn tiền** (mua ảnh, mua tên miền).

## Khi gặp vấn đề

- Trang trắng sau khi gắn: mở console trình duyệt xem lỗi; chạy `ap-dung-giao-dien.mjs --go` để về như cũ, báo lại.
- Phông không hiện đủ dấu tiếng Việt: chỉ dùng phông trong `chu-de.json` (đã kiểm có tiếng Việt). Muốn phông khác phải thử chuỗi "Ặ Ở Ữ ệ ợ ỳ" trước.
- Biểu tượng không hiện khi mở bằng `file://`: bình thường, trình duyệt chặn; xem qua `http://localhost` (demo của CRM đã phát đúng cách).
