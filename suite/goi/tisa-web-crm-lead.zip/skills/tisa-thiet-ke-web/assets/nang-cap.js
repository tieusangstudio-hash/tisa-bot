/* TISA tisa-thiet-ke-web: hiệu ứng nhẹ cho Lead Page / Sale Page. Không thư viện ngoài, không gửi dữ liệu đi đâu.
   Tắt hết khi người dùng chọn giảm chuyển động. Nếu JS lỗi, trang vẫn hiện đủ nội dung. */
(function () {
  "use strict";
  var d = document, root = d.documentElement, body = d.body;
  var giam = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }

  // 1. Liên kết bỏ qua menu (cho bàn phím, trình đọc màn hình)
  var main = d.getElementById("top") || d.querySelector("main");
  if (main) {
    if (!main.id) main.id = "top";
    var bq = d.createElement("a"); bq.className = "bo-qua"; bq.href = "#" + main.id; bq.textContent = "Bỏ qua, đến nội dung chính";
    body.insertBefore(bq, body.firstChild);
  }

  // 2. Thanh trên đổ bóng khi cuộn
  var tb = d.querySelector(".topbar");
  function cuon() { if (tb) tb.classList.toggle("is-scrolled", window.scrollY > 8); }
  cuon(); window.addEventListener("scroll", cuon, { passive: true });

  // 3. Mũi tên trên nút chính
  $$(".hero-offer .btn, .stack-price .btn, .section.dark .btn, .urgent .btn").forEach(function (b) { if (b.tagName === "A") b.classList.add("co-mui-ten"); });

  // 4. Dòng "an tâm" dưới nút gửi của form (chỉ khi chưa có và form có nút gửi)
  $$(".form-card").forEach(function (f) {
    if (f.querySelector(".an-tam")) return;
    var msg = f.querySelector(".form-message");
    var p = d.createElement("p"); p.className = "an-tam"; p.textContent = "Thông tin của bạn được giữ kín, chỉ dùng để liên hệ lại.";
    if (msg) f.insertBefore(p, msg); else f.appendChild(p);
  });

  // 5. Hiện dần khi cuộn
  if (!giam && "IntersectionObserver" in window) {
    var chon = ".section-head, .card, .stack, .guarantee, .old-new > div, .before-after .row, .fit .card, .urgent, .split > *, .faq details, .trust-item, .story, .cost-band";
    var ds = $$(chon).filter(function (e) { return !e.closest(".hero-offer"); });
    ds.forEach(function (e) {
      var cha = e.parentElement, anh = cha ? $$(chon, cha).filter(function (x) { return x.parentElement === cha; }) : [e];
      e.style.setProperty("--i", Math.min(Math.max(anh.indexOf(e), 0), 5));
      e.classList.add("reveal");
    });
    root.classList.add("nc-reveal");
    var qs = new IntersectionObserver(function (es) {
      es.forEach(function (x) { if (x.isIntersecting) { x.target.classList.add("in"); qs.unobserve(x.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    ds.forEach(function (e) { qs.observe(e); });
    // An toàn: nếu 4 giây sau vẫn còn khối chưa hiện (cuộn nhảy, in trang), hiện hết.
    setTimeout(function () { ds.forEach(function (e) { e.classList.add("in"); }); }, 4000);
  }

  // 6. Thanh CTA dưới điện thoại: hiện sau khi cuộn qua màn hình đầu, ẩn khi đang ở chỗ form đăng ký
  var st = d.querySelector(".sticky-cta");
  if (st) {
    var forms = $$(".form-card"), thayForm = false;
    var capNhat = function () { st.classList.toggle("is-on", window.scrollY > 520 && !thayForm); };
    if ("IntersectionObserver" in window && forms.length) {
      var of = new IntersectionObserver(function (es) {
        es.forEach(function (x) { x.target._thay = x.isIntersecting; });
        thayForm = forms.some(function (f) { return f._thay; }); capNhat();
      });
      forms.forEach(function (f) { of.observe(f); });
    }
    window.addEventListener("scroll", capNhat, { passive: true }); capNhat();
  }

  // 7. Nút Zalo / gọi nổi: CHỈ hiện khi trang có khai báo số thật, vd <body data-zalo="0909123456" data-goi="0909123456">
  function so(s) { s = String(s || "").replace(/[^\d+]/g, ""); return /^(\+?84|0)\d{8,10}$/.test(s) ? s : ""; }
  var z = so(body.getAttribute("data-zalo")), g = so(body.getAttribute("data-goi"));
  if (z || g) {
    var box = d.createElement("div"); box.className = "lien-he-noi";
    var svg = function (id) { return '<svg class="ico" aria-hidden="true"><use href="' + base() + "nang-cap/icons.svg#" + id + '"/></svg>'; };
    if (z) box.insertAdjacentHTML("beforeend", '<a class="zalo" href="https://zalo.me/' + z.replace(/^\+?84/, "0") + '" target="_blank" rel="noopener">' + svg("chat") + "<span>Nhắn Zalo</span></a>");
    if (g) box.insertAdjacentHTML("beforeend", '<a class="goi" href="tel:' + g + '">' + svg("phone") + "<span>Gọi ngay</span></a>");
    body.appendChild(box);
  }
  function base() {
    var s = d.querySelector('script[src*="nang-cap/nang-cap.js"]'); if (!s) return "";
    return s.getAttribute("src").replace("nang-cap/nang-cap.js", "");
  }

  // 8. Đếm số khi cuộn tới: chỉ cho con số THẬT mà chủ đã cung cấp, vd <b data-dem="1200">0</b>
  if (!giam && "IntersectionObserver" in window) {
    var ob = new IntersectionObserver(function (es) {
      es.forEach(function (x) {
        if (!x.isIntersecting) return; ob.unobserve(x.target);
        var el = x.target, to = parseFloat(el.getAttribute("data-dem")), t0 = performance.now(), dur = 1200;
        if (!isFinite(to)) return;
        (function buoc(t) {
          var k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
          el.textContent = Math.round(to * e).toLocaleString("vi-VN");
          if (k < 1) requestAnimationFrame(buoc);
        })(t0);
      });
    }, { threshold: 0.4 });
    $$("[data-dem]").forEach(function (e) { ob.observe(e); });
  }
})();
