#!/usr/bin/env node
// TISA tisa-thiet-ke-web: gắn lớp giao diện chuyên nghiệp vào Lead Page, Sale Page, trang cảm ơn.
// Chạy lại nhiều lần an toàn (không nhân đôi). Không sửa chữ, form, hay lead-config.js.
//
//   node ap-dung-giao-dien.mjs --thu-muc <thư mục lead> --chu-de <id>      gắn hoặc đổi chủ đề
//   node ap-dung-giao-dien.mjs --thu-muc <thư mục lead> --go               gỡ hết, về như cũ
//   node ap-dung-giao-dien.mjs --danh-sach                                 liệt kê chủ đề
//
// Tệp sao vào <thư mục lead>/nang-cap/. Trang nào chưa có thì bỏ qua.
import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const AQ = join(dirname(fileURLToPath(import.meta.url)), "..", "assets");
const CHU_DE = JSON.parse(readFileSync(join(AQ, "chu-de.json"), "utf8"));
const TRANG = ["index.html", "ban-hang/index.html", "cam-on/index.html"];
const TEP = ["nang-cap.css", "nang-cap.js", "chu-de.css", "icons.svg"];
const DANH_DAU = "<!-- tisa-nang-cap -->";

const arg = (k) => { const i = process.argv.indexOf(k); return i < 0 ? null : (process.argv[i + 1] && !process.argv[i + 1].startsWith("--") ? process.argv[i + 1] : true); };

if (arg("--danh-sach")) {
  for (const [id, t] of Object.entries(CHU_DE)) console.log(`${id.padEnd(22)} ${t.ten}: ${t.nganh}`);
  process.exit(0);
}

const goc = resolve(arg("--thu-muc") || process.cwd());
if (!existsSync(join(goc, "index.html"))) { console.error(`LỖI: ${goc} không phải thư mục Lead Page (thiếu index.html).`); process.exit(1); }
const go = !!arg("--go");
const id = arg("--chu-de");
if (!go && id && id !== true && !CHU_DE[id]) { console.error(`LỖI: chủ đề "${id}" không có. Chọn: ${Object.keys(CHU_DE).join(", ")}`); process.exit(1); }
const chuDe = go ? null : (id && id !== true ? id : null);

const phongUrl = (ids) => {
  const f = [...new Set(ids)].map((p) => `family=${p.replace(/ /g, "+")}:wght@400;500;600;700;800`).join("&");
  return `https://fonts.googleapis.com/css2?${f}&display=swap`;
};

function xuLy(ten) {
  const dg = join(goc, ten);
  if (!existsSync(dg)) return `bỏ qua ${ten} (không có)`;
  let h = readFileSync(dg, "utf8");
  const sau = ten.includes("/") ? "../" : "";
  // dọn bản cũ
  h = h.replace(/\n?[ \t]*<!-- tisa-nang-cap -->[^\n]*\n?/g, "\n").replace(/[ \t]*<link rel="stylesheet" href="[^"]*nang-cap\/[^"]*">\n?/g, "")
    .replace(/[ \t]*<script src="[^"]*nang-cap\/nang-cap\.js"[^>]*><\/script>\n?/g, "")
    .replace(/[ \t]*<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com\/css2\?[^"]*" data-tisa="chu-de">\n?/g, "")
    .replace(/ data-chu-de="[^"]*"/, "");
  if (go) { writeFileSync(dg, h); return `đã gỡ khỏi ${ten}`; }
  // data-chu-de trên <html>
  if (chuDe) h = h.replace(/<html([^>]*)>/i, (m, a) => `<html${a} data-chu-de="${chuDe}">`);
  // css: ngay sau styles.css
  const cssTag = `${DANH_DAU}\n<link rel="stylesheet" href="${sau}nang-cap/chu-de.css">\n<link rel="stylesheet" href="${sau}nang-cap/nang-cap.css">`;
  const phongTag = chuDe ? `<link rel="stylesheet" href="${phongUrl(CHU_DE[chuDe].phong)}" data-tisa="chu-de">\n` : "";
  if (/<link rel="stylesheet" href="[^"]*styles\.css"[^>]*>/i.test(h)) h = h.replace(/(<link rel="stylesheet" href="[^"]*styles\.css"[^>]*>)/i, `$1\n${phongTag}${cssTag}`);
  else h = h.replace(/<\/head>/i, `${phongTag}${cssTag}\n</head>`);
  // js: trước </body>
  h = h.replace(/<\/body>/i, `<script src="${sau}nang-cap/nang-cap.js" defer></script>\n</body>`);
  // theme-color + Open Graph nếu thiếu
  if (chuDe) {
    const mau = CHU_DE[chuDe].primary;
    if (/<meta name="theme-color"/i.test(h)) h = h.replace(/(<meta name="theme-color" content=")[^"]*(")/i, `$1${mau}$2`);
    else h = h.replace(/<\/head>/i, `<meta name="theme-color" content="${mau}">\n</head>`);
  }
  const tieuDe = (h.match(/<title>([^<]*)<\/title>/i) || [])[1];
  const mota = (h.match(/<meta name="description" content="([^"]*)"/i) || [])[1];
  const them = [];
  if (tieuDe && !/property="og:title"/i.test(h)) them.push(`<meta property="og:title" content="${tieuDe}">`);
  if (mota && !/property="og:description"/i.test(h)) them.push(`<meta property="og:description" content="${mota}">`);
  if (!/property="og:type"/i.test(h)) them.push(`<meta property="og:type" content="website">`, `<meta property="og:locale" content="vi_VN">`);
  if (!/name="twitter:card"/i.test(h)) them.push(`<meta name="twitter:card" content="summary_large_image">`);
  if (them.length) h = h.replace(/<\/head>/i, `${them.join("\n")}\n</head>`);
  writeFileSync(dg, h);
  return `đã gắn vào ${ten}`;
}

if (go) {
  const kq = TRANG.map(xuLy);
  rmSync(join(goc, "nang-cap"), { recursive: true, force: true });
  console.log(kq.join("\n") + "\nĐã xóa thư mục nang-cap.");
} else {
  mkdirSync(join(goc, "nang-cap"), { recursive: true });
  for (const f of TEP) copyFileSync(join(AQ, f), join(goc, "nang-cap", f));
  const kq = TRANG.map(xuLy);
  console.log(kq.join("\n") + `\nChủ đề: ${chuDe || "(giữ màu hiện tại của styles.css)"}\nTệp ở: ${join(goc, "nang-cap")}`);
}
