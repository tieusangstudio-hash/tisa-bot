#!/usr/bin/env node
// TISA tisa-thiet-ke-web: soát nhanh Lead Page, Sale Page, trang cảm ơn trước khi cho khách xem hoặc đăng.
// Chỉ ĐỌC, không sửa gì. Nhìn bằng mắt (điện thoại, máy tính) vẫn là bước bắt buộc, script không thay được.
//
//   node soat-trang.mjs --thu-muc <thư mục lead> [--dang]     --dang: soát chặt hơn cho bản sắp đăng thật
//
// Kết quả: LỖI (phải sửa) / CẢNH BÁO (nên sửa) / ĐẠT. Thoát mã 1 nếu có LỖI.
import { readFileSync, existsSync, statSync, readdirSync } from "node:fs";
import { join, resolve, dirname, extname } from "node:path";

const arg = (k) => { const i = process.argv.indexOf(k); return i < 0 ? null : (process.argv[i + 1] && !process.argv[i + 1].startsWith("--") ? process.argv[i + 1] : true); };
const goc = resolve(arg("--thu-muc") || process.cwd());
const dang = !!arg("--dang");
if (!existsSync(join(goc, "index.html"))) { console.error(`LỖI: ${goc} thiếu index.html`); process.exit(1); }

const loi = [], canhBao = [], dat = [];
const L = (t, m) => loi.push(`${t}: ${m}`), W = (t, m) => canhBao.push(`${t}: ${m}`), OK = (t, m) => dat.push(`${t}: ${m}`);
const TRANG = [["index.html", "Lead Page"], ["ban-hang/index.html", "Sale Page"], ["cam-on/index.html", "Trang cảm ơn"]];

const luminance = (hex) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((x) => (x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4)); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
const tuongPhan = (a, b) => { const x = luminance(a), y = luminance(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };

// ----- CSS: màu thương hiệu có đọc được không
try {
  const css = readFileSync(join(goc, "styles.css"), "utf8");
  const bien = {}; for (const m of css.matchAll(/--([\w-]+):\s*(#[0-9a-fA-F]{6})\b/g)) bien[m[1]] = m[2];
  let cd = null; const hd = readFileSync(join(goc, "index.html"), "utf8").match(/data-chu-de="([^"]+)"/);
  if (hd && existsSync(join(goc, "nang-cap/chu-de.css"))) {
    const blk = readFileSync(join(goc, "nang-cap/chu-de.css"), "utf8").match(new RegExp(`data-chu-de="${hd[1]}"\\]\\s*{([^}]*)}`));
    if (blk) { cd = hd[1]; for (const m of blk[1].matchAll(/--([\w-]+):\s*(#[0-9a-fA-F]{6})\b/g)) bien[m[1]] = m[2]; }
  }
  const cap = [["ink", "white", "chữ chính trên nền trắng"], ["muted", "white", "chữ phụ trên nền trắng"], ["accent-deep", "white", "chữ nhấn trên nền trắng"]];
  bien.white = bien.white || "#ffffff";
  for (const [a, b, mo] of cap) if (bien[a] && bien[b]) {
    const r = tuongPhan(bien[a], bien[b]);
    if (r < 4.5) L("Màu", `${mo} chỉ ${r.toFixed(1)}:1 (cần từ 4.5:1) → khó đọc, đổi đậm hơn`); else OK("Màu", `${mo} ${r.toFixed(1)}:1`);
  }
  if (cd) OK("Chủ đề", cd);
} catch { W("Màu", "không đọc được styles.css"); }

const dsTepAnh = [];
for (const [rel, ten] of TRANG) {
  const dg = join(goc, rel);
  if (!existsSync(dg)) { if (rel !== "cam-on/index.html") W(ten, `thiếu ${rel}`); continue; }
  const h = readFileSync(dg, "utf8"), t = ten;
  const noi = h.replace(/<!--[\s\S]*?-->/g, "").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  const chu = noi.replace(/<[^>]+>/g, " ");

  // Nền tảng
  /<html[^>]*lang="vi"/i.test(h) ? OK(t, 'lang="vi"') : L(t, 'thiếu lang="vi" trên <html>');
  /<meta name="viewport"[^>]*width=device-width/i.test(h) ? OK(t, "viewport") : L(t, "thiếu meta viewport, điện thoại sẽ hiện rất nhỏ");
  const tieuDe = (h.match(/<title>([^<]*)<\/title>/i) || [])[1] || "";
  if (!tieuDe) L(t, "thiếu <title>"); else if (tieuDe.length > 70) W(t, `title dài ${tieuDe.length} ký tự, Google cắt sau ~60`); else OK(t, `title ${tieuDe.length} ký tự`);
  const mota = (h.match(/<meta name="description" content="([^"]*)"/i) || [])[1] || "";
  if (rel !== "cam-on/index.html") { if (!mota) W(t, "thiếu meta description"); else if (mota.length > 170) W(t, `description dài ${mota.length} ký tự, nên ≤160`); else if (mota.length < 50) W(t, "description quá ngắn"); }
  if (rel !== "cam-on/index.html" && !/property="og:image"/i.test(h)) W(t, "chưa có og:image: chia sẻ link lên Zalo/Facebook sẽ không có ảnh đẹp. Thêm <meta property=\"og:image\" content=\"https://…/anh.jpg\"> (1200x630) khi đã có tên miền");
  const h1 = (noi.match(/<h1[\s>]/gi) || []).length;
  h1 === 1 ? OK(t, "đúng 1 thẻ h1") : L(t, `có ${h1} thẻ h1, cần đúng 1`);

  // Ảnh
  for (const m of noi.matchAll(/<img\b[^>]*>/gi)) {
    const i = m[0], src = (i.match(/src="([^"]*)"/) || [])[1] || "";
    if (!/\balt="/.test(i)) L(t, `ảnh ${src} thiếu alt`);
    else if (/\balt=""/.test(i) && !/aria-hidden/.test(i)) W(t, `ảnh ${src} alt rỗng (chỉ đúng khi ảnh trang trí)`);
    if (!/\bwidth="/.test(i) || !/\bheight="/.test(i)) W(t, `ảnh ${src} thiếu width/height → trang bị giật khi tải`);
    if (src && !/^(https?:|data:)/.test(src)) dsTepAnh.push(join(dirname(dg), src));
  }

  // Còn chữ mẫu / giả định
  for (const [re, nhan] of [[/\(mẫu\)/g, "chữ (mẫu)"], [/\(giả định\)/g, "chữ (giả định)"], [/\bNOVA\b/g, "tên doanh nghiệp mẫu NOVA"], [/máy lọc|lọc nước/gi, "chữ ngành máy lọc nước của bản mẫu"], [/Chỗ đặt/g, "ô giữ chỗ \"Chỗ đặt…\""], [/doanh nghiệp bạn đặt ở đây/g, "địa chỉ giữ chỗ ở chân trang"]]) {
    const n = (chu.match(re) || []).length;
    if (n) (dang ? L : W)(t, `còn ${n} chỗ ${nhan} → thay bằng nội dung thật trước khi đăng`);
  }
  // Cam kết giả
  if (/đếm ngược|countdown|chỉ còn \d+ (suất|chỗ|slot|phần)/i.test(noi)) L(t, "có vẻ đếm ngược / số chỗ giả. Chỉ dùng khi giới hạn là thật");
  if (/[“"]?(hơn|trên) ?\d[\d.,]* ?(khách|học viên|người|đơn)/i.test(chu)) W(t, "có con số khách/đơn: chắc chắn là số THẬT và có thể chứng minh?");
  if (/noindex/i.test(h)) (dang ? L : OK)(t, dang ? "còn meta robots noindex: Google sẽ KHÔNG hiện trang này. Xóa dòng đó khi đăng thật" : "đang noindex (đúng khi còn là bản thử)");

  // Form
  if (rel !== "cam-on/index.html") {
    if (!/id="lead-form"/.test(h)) L(t, 'thiếu form id="lead-form" → khách không vào được CRM');
    else {
      for (const f of ["name", "phone", "consent", "website"]) if (!new RegExp(`name="${f}"`).test(h)) L(t, `form thiếu ô name="${f}"`);
      const o = (h.match(/<form[\s\S]*?<\/form>/i)[0].match(/<(input|select|textarea)\b/gi) || []).length;
      o > 7 ? W(t, `form có ${o} ô, càng ít càng nhiều người điền`) : OK(t, `form ${o} ô`);
    }
    /<a\b[^>]*class="[^"]*btn/i.test(h) ? OK(t, "có nút kêu gọi") : W(t, "không thấy nút kêu gọi");
  }
  // Liên kết ra ngoài
  for (const m of noi.matchAll(/<a\b[^>]*target="_blank"[^>]*>/gi)) if (!/rel="[^"]*noopener/.test(m[0])) W(t, "liên kết mở tab mới thiếu rel=\"noopener\"");
  for (const m of noi.matchAll(/href="(\/[^"#?]*|\.\.?\/[^"#?]*)"/g)) {
    const p = join(dirname(dg), m[1]); if (m[1] !== "/" && !existsSync(p) && !existsSync(join(p, "index.html")) && !existsSync(join(goc, m[1]))) W(t, `liên kết nội bộ hỏng: ${m[1]}`);
  }
  // Mã khai báo màu nội tuyến quá nhiều
  const nhung = (h.match(/style="/g) || []).length;
  if (nhung > 14) W(t, `có ${nhung} style nội tuyến: khó đổi chủ đề, nên đưa vào CSS`);
  if (/<img[^>]*src="[^"]*\.(png|jpe?g)"/i.test(noi) && (noi.match(/<img/gi) || []).length > 1 && !/loading="lazy"/.test(noi)) W(t, "nhiều ảnh nhưng không có loading=\"lazy\" (ảnh đầu trang không cần lazy)");
}

// ----- Dung lượng ảnh
for (const f of [...new Set(dsTepAnh)]) {
  if (!existsSync(f)) { L("Ảnh", `thiếu tệp ${f.replace(goc, "")}`); continue; }
  const kb = statSync(f).size / 1024;
  if (kb > 600) W("Ảnh", `${f.replace(goc, "")} nặng ${Math.round(kb)} KB → nén xuống dưới 300 KB (WebP hoặc JPEG chất lượng 80), điện thoại 4G sẽ tải chậm`);
  else OK("Ảnh", `${f.replace(goc, "")} ${Math.round(kb)} KB`);
}
// ----- Cấu hình nối CRM
try {
  const cf = readFileSync(join(goc, "lead-config.js"), "utf8");
  const ep = (cf.match(/crmEndpoint\s*[:=]\s*["']([^"']*)["']/) || [])[1];
  if (!ep) W("Nối CRM", "lead-config.js chưa có crmEndpoint → form chưa gửi được về CRM");
  else if (/localhost|127\.0\.0\.1/.test(ep)) (dang ? L : W)("Nối CRM", `crmEndpoint đang là ${ep} (chỉ chạy trên máy anh chị). Khi đăng thật phải đổi sang địa chỉ công khai của CRM`);
  else OK("Nối CRM", ep);
} catch { /* không có thì thôi */ }
// ----- Lớp giao diện
existsSync(join(goc, "nang-cap/nang-cap.css")) ? OK("Giao diện", "đã gắn lớp nang-cap") : W("Giao diện", "chưa gắn lớp giao diện nâng cấp (ap-dung-giao-dien.mjs)");

const xuat = (ten, ds, bieu) => { if (ds.length) { console.log(`\n${bieu} ${ten} (${ds.length})`); ds.forEach((x) => console.log("  - " + x)); } };
xuat("LỖI, phải sửa", loi, "✖"); xuat("CẢNH BÁO, nên sửa", canhBao, "▲");
console.log(`\n✔ ĐẠT ${dat.length} mục.`);
console.log(loi.length ? `\nKẾT LUẬN: CHƯA ĐẠT, còn ${loi.length} lỗi.` : canhBao.length ? `\nKẾT LUẬN: dùng được, còn ${canhBao.length} cảnh báo.` : "\nKẾT LUẬN: sạch.");
console.log("Nhớ: soát bằng mắt trên điện thoại (390px) và máy tính (1280px) trước khi giao.");
process.exit(loi.length ? 1 : 0);
