# Ảnh và biểu tượng

Ảnh quyết định khách tin hay không nhiều hơn chữ. Ưu tiên theo thứ tự: **ảnh thật của chủ** → ảnh tự tạo bằng AI (chỉ khi là ảnh minh họa, không giả làm bằng chứng) → ảnh stock có giấy phép → ô giữ chỗ viền đứt.

## 1. Ảnh thật (tốt nhất)

Hỏi chủ: công trình đã làm, sản phẩm, đội ngũ, xưởng, không gian, khách đang dùng (đã xin phép). Dặn cách chụp bằng điện thoại: ánh sáng ban ngày gần cửa sổ, lau ống kính, chụp ngang, dọn đồ thừa khỏi khung, chụp 3 góc (toàn cảnh, trung cảnh, chi tiết). Video ngắn 10 đến 20 giây cũng rất giá trị.

## 2. Ảnh minh họa tạo bằng AI

Chỉ dùng cho **ảnh minh họa không khẳng định điều gì** (nền, không gian chung, vật dụng). Không dùng làm:
- ảnh "công trình đã làm" hay "sản phẩm của chúng tôi" nếu không phải thật;
- ảnh khách hàng, cảm nhận, nhân viên (là bịa bằng chứng);
- ảnh có chữ, logo, khuôn mặt người thật.

Lời nhắc theo cấu trúc: **chủ thể + bối cảnh + ánh sáng + góc + phong cách + tỉ lệ + điều cấm**.

| Ngành | Lời nhắc mẫu (đổi theo doanh nghiệp) |
|---|---|
| Nhà đất, xây dựng | "Phòng khách nhà phố Việt Nam hiện đại, ánh sáng ban ngày qua cửa kính, sàn gỗ sáng, sofa màu be, cây xanh nhỏ, góc chụp ngang tầm mắt, ảnh kiến trúc thực tế, tỉ lệ 3:2, không chữ, không logo, không người" |
| Ẩm thực, cà phê | "Cốc cà phê sữa đá trên bàn gỗ cạnh cửa sổ quán, ánh nắng sớm, độ sâu trường ảnh nông, tông ấm, tỉ lệ 4:3, không chữ" |
| Khóa học, kỹ năng | "Bàn làm việc gọn gàng với laptop, sổ tay và cốc nước, ánh sáng tự nhiên, nhìn từ trên xuống, tông xanh nhạt, tỉ lệ 16:9, không chữ, không người" |
| Y tế, sức khỏe | "Rau củ tươi trên bàn bếp trắng, ánh sáng mềm, màu tự nhiên, tỉ lệ 3:2, không chữ" |
| Mỹ phẩm, spa | "Sản phẩm chăm sóc da trên đá cẩm thạch trắng với bóng đổ mềm, tông hồng nhạt, tỉ lệ 4:5, không chữ, không nhãn hiệu" |
| Công nghệ | "Nền trừu tượng gradient xanh đen với lưới điểm mờ, tối giản, tỉ lệ 16:9, không chữ" |

Thông báo cho chủ nếu ảnh là minh họa AI (thêm dòng "Ảnh minh họa" cạnh ảnh khi ảnh có thể bị hiểu là thật).

Không có công cụ tạo ảnh: vẽ nền SVG đơn giản (hình khối, gradient) hoặc **bỏ ảnh**, giữ trang gọn. Một trang không ảnh nhưng chữ rõ vẫn tốt hơn một trang ảnh sai ngành.

## 3. Ảnh stock

Chỉ dùng nguồn cho phép dùng thương mại và không yêu cầu ghi nguồn (Unsplash, Pexels, Pixabay: **đọc giấy phép từng ảnh**). Tránh ảnh người mẫu cười kiểu quảng cáo cũ và ảnh người nước ngoài cho dịch vụ trong nước. Không mua ảnh trả phí khi chủ chưa đồng ý.

## 4. Chuẩn bị ảnh để trang nhanh

| Việc | Chuẩn |
|---|---|
| Kích thước | Ảnh đầu trang rộng 1600px; ảnh trong thẻ rộng 800px; avatar 160px |
| Dung lượng | Mỗi ảnh < 300 KB, tổng ảnh màn hình đầu < 1 MB |
| Định dạng | WebP hoặc JPEG chất lượng 78 đến 82. Logo và biểu tượng dùng SVG |
| Thuộc tính | `width` và `height` đúng tỉ lệ thật (tránh giật), `alt` mô tả, `loading="lazy"` cho ảnh dưới màn hình đầu, **không** lazy cho ảnh đầu trang |
| Ảnh chia sẻ | `og:image` 1200x630px, chữ ít, thêm khi đã có tên miền thật |

Nén trên máy Mac không cần cài gì: `sips -s format jpeg -s formatOptions 80 -Z 1600 anh.png --out anh.jpg`. Windows hoặc cần WebP: dùng squoosh.app (xử lý ngay trong trình duyệt, ảnh không rời máy) hoặc công cụ nén anh chị đã có.

## 5. Alt (mô tả ảnh)

Mô tả điều ảnh cho thấy, ≤ 125 ký tự, không nhồi từ khóa. Ảnh trang trí thuần túy: `alt=""` và `aria-hidden="true"`. Ví dụ tốt: "Phòng khách nhà phố 4 tầng sau khi hoàn thiện ở Gò Vấp". Ví dụ tệ: "nhà đẹp giá rẻ nhà phố gò vấp quận 12".

## 6. Biểu tượng

- Dùng bộ `nang-cap/icons.svg` (19 biểu tượng nét 2px, bo đầu, kế thừa màu chữ). Cú pháp ở `bo-cuc-theo-khoi.md`.
- Không dùng emoji làm biểu tượng ở khối bán hàng (mỗi máy hiển thị một kiểu, nhìn thiếu chuyên nghiệp). Emoji chỉ chấp nhận trong chat, không trong trang.
- Logo: xin chủ bản SVG hoặc PNG nền trong suốt. Chỉ có ảnh chụp logo thì làm sạch nền, hoặc dùng ô chữ cái đầu (`.brand-mark`) tạm thời. Đổi favicon trong dòng `<link rel="icon">` đầu trang.
- Cần biểu tượng mới: vẽ SVG theo cùng quy cách (24x24, stroke 2, không fill) rồi thêm vào `<symbol>` của `icons.svg`. Không dán biểu tượng lấy ở nơi không rõ giấy phép.
