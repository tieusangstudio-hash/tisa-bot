# Nâng bố cục từng khối

Mẫu HTML dưới đây **dùng đúng các class đã có** trong `styles.css` và `nang-cap.css`. Dán vào chỗ phù hợp, đổi chữ. Đường dẫn biểu tượng: trang gốc dùng `nang-cap/icons.svg#tên`, trang con (`ban-hang/`, `cam-on/`) dùng `../nang-cap/icons.svg#tên`.

Biểu tượng có sẵn: `check shield clock phone chat pin star arrow home heart bolt users gift lock ruler tool video chart calendar`.

## Nguyên tắc chung

- **Một khối, một ý, một việc khách làm tiếp.** Khối nào không giúp khách tin hoặc hành động thì bỏ.
- **Thứ bậc:** mỗi khối có đúng một thứ lớn nhất (tiêu đề), một thứ nhì (đoạn dẫn), còn lại nhỏ. Nheo mắt nhìn trang: phải thấy được thứ tự đọc.
- **Điểm nhấn hiếm:** mỗi màn hình điện thoại chỉ một thứ màu nhấn nổi nhất, thường là nút.
- **Căn lề trái cho đoạn dài.** Căn giữa chỉ cho tiêu đề ngắn và lời mời cuối.

## 1. Màn hình đầu (Lead Page, Sale Page)

Việc cần đạt: trong 5 giây khách biết **trang này cho ai, được gì, làm gì tiếp**.

- Tiêu đề ≤ 12 từ nếu được, ≤ 5 dòng trên điện thoại. Cụm kết quả quan trọng nhất bọc `<mark>` để có vạch nhấn: `Biết đúng máy nhà mình cần <mark>sau 15 phút</mark>`.
- Dòng dẫn (`.lede`) một đến hai câu. Ba lợi ích (`.gain-list`) ngắn.
- Điện thoại: form hoặc nút chính phải nằm trong **một lần cuộn** từ đầu trang.
- Không đặt menu dài, banner khuyến mãi, hay thanh cảnh báo phía trên màn hình đầu.

## 2. Dải tin cậy (đặt ngay sau màn hình đầu)

Chỉ đưa ý **thật và kiểm chứng được**: giấy phép, năm hoạt động, bảo hành, khu vực, hình thức thanh toán, cam kết đã được chủ xác nhận. Không có ý nào thật thì **bỏ nguyên dải**.

```html
<section class="trust-strip" aria-label="Điểm bảo đảm">
  <div class="wrap">
    <div class="trust-item"><svg class="ico" aria-hidden="true"><use href="nang-cap/icons.svg#shield"/></svg>Bảo hành 12 tháng bằng văn bản</div>
    <div class="trust-item"><svg class="ico" aria-hidden="true"><use href="nang-cap/icons.svg#pin"/></svg>Phục vụ Gò Vấp, Quận 12, Tân Bình</div>
    <div class="trust-item"><svg class="ico" aria-hidden="true"><use href="nang-cap/icons.svg#clock"/></svg>Phản hồi trong giờ làm việc</div>
    <div class="trust-item"><svg class="ico" aria-hidden="true"><use href="nang-cap/icons.svg#lock"/></svg>Thông tin được giữ kín</div>
  </div>
</section>
```

## 3. Thẻ lợi ích có biểu tượng

Thay thẻ chỉ có chữ bằng thẻ có khung biểu tượng. Một thẻ = một lợi ích = một câu tiêu đề + một câu giải thích.

```html
<article class="card">
  <span class="ico-bubble"><svg class="ico" aria-hidden="true"><use href="nang-cap/icons.svg#ruler"/></svg></span>
  <h3>Đo đạc và tư vấn tại nhà</h3>
  <p>Kỹ thuật viên đến đo, báo giá trọn gói trước khi anh chị quyết định.</p>
</article>
```

Chọn biểu tượng đúng nghĩa: `shield` an tâm, `clock` nhanh/đúng giờ, `gift` quà, `users` đội ngũ/cộng đồng, `tool` lắp đặt/sửa, `chart` kết quả, `calendar` lịch hẹn, `video` hướng dẫn, `home` nhà, `heart` chăm sóc, `bolt` nhanh.

## 4. Cảm nhận khách thật (chỉ khi có thật và khách đồng ý)

```html
<article class="card quote-card">
  <h3>“Lắp trong buổi sáng, dọn sạch sẽ, gọi hỏi là có người trả lời ngay.”</h3>
  <p><strong>Chị Lan</strong>, Gò Vấp. Đã dùng từ 03/2026</p>
</article>
```

Không bịa tên, không dùng ảnh đại diện lấy từ mạng. Có ảnh khách thật và khách đồng ý thì thêm ảnh tròn 48px phía trên tên. Chưa có thì giữ ô `.slot` viền đứt.

## 5. Bảng giá / gói (Sale Page)

- **Một gói nổi bật** (to hơn, có viền màu nhấn, có nhãn "Được chọn nhiều" **chỉ khi đúng thật**). Hai đến ba gói là đủ; nhiều hơn khách bối rối (luật Hick).
- Mỗi dòng "gồm" bắt đầu bằng động từ, một biểu tượng `check`. Dòng "không gồm" ghi rõ để khỏi hiểu lầm.
- Giá có **đơn vị và điều kiện** ngay cạnh ("/ tháng", "đã gồm VAT", "chưa gồm vật tư"). Giá giả định có chữ "(giả định)".
- Bên dưới nút có một dòng giảm lo lắng: cách thanh toán, hoàn tiền (**chỉ khi chủ cam kết thật**).

## 6. So sánh cũ và mới (`.old-new`) hoặc trước và sau (`.before-after`)

Bảng hai cột, bên mới nổi bằng nền màu chủ đạo (đã có sẵn). Mỗi dòng cùng một tiêu chí hai bên. Tối đa 5 dòng. Không so sánh với tên đối thủ cụ thể.

## 7. Hỏi đáp (`.faq`)

Mở sẵn câu đầu tiên. Câu hỏi viết như khách gõ ("Có bị gọi làm phiền không?"). Trả lời ≤ 3 dòng, câu cuối dẫn về hành động nếu hợp. Đã có dấu cộng xoay tự động.

## 8. Lời mời cuối (`.section.dark`)

Nhắc lại **đúng lời hứa** ở màn hình đầu, một nút, cùng chữ trên nút. Không thêm lựa chọn mới ở đây.

## 9. Điện thoại (kiểm tra riêng ở 390px)

- Vùng bấm ≥ 44px cao, khoảng cách giữa hai nút ≥ 8px.
- Ô nhập `font-size` ≥ 16px (đã có). Dùng `inputmode="tel"` cho số điện thoại (đã có).
- Thanh CTA dính dưới màn hình tự hiện sau khi cuộn qua phần đầu và tự ẩn khi khách đang ở chỗ form (đã có, `.sticky-cta`).
- Không có thanh cuộn ngang. Kiểm tra: `document.documentElement.scrollWidth` phải ≤ chiều rộng màn hình.
- Chữ trên ảnh phải có lớp phủ đủ tối hoặc sáng để đọc được.

## 10. Trang cảm ơn

Việc của trang: **khách yên tâm và làm bước tiếp theo**. Có: lời xác nhận cụ thể ("Chúng tôi gọi lại trong giờ làm việc"), một bước tiếp có ích (kết bạn Zalo, xem video hướng dẫn, đặt lịch), không có quảng cáo thêm. Bước tiếp phải **thật** và đã được chủ duyệt.

## 11. Bố cục khác để chọn (khi trang mẫu chưa hợp)

| Tình huống | Cách đổi |
|---|---|
| Có ảnh sản phẩm/công trình đẹp, dọc | Màn hình đầu chia đôi: chữ trái, ảnh phải, form xuống khối kế |
| Dịch vụ cần tin cậy, chưa có ảnh | Màn hình đầu chữ + form (bản mẫu), dải tin cậy bên dưới |
| Ngành nhiều lựa chọn (BĐS, nội thất) | Thêm khối lưới 3 đến 6 ảnh dự án, mỗi ảnh một dòng chú thích và một nút "Hỏi dự án này" dẫn về form |
| Cần giải thích quy trình | Khối ba đến bốn bước (`.num`) có đường nối |

Đổi bố cục xong thì kiểm tra lại ba nơi tên sản phẩm phải trùng nhau (xem `tisa-web-crm-lead`).
