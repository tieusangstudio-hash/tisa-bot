# Chuyển động và chi tiết hoàn thiện

Chi tiết nhỏ làm trang trông "đắt tiền". Nhưng **chuyển động phải phục vụ khách**, không phải để khoe. Quy tắc: nếu bỏ hiệu ứng đi mà khách không mất gì, thì hiệu ứng đó thừa.

## Cái đã có sẵn trong `nang-cap.js` / `nang-cap.css`

| Hiệu ứng | Mục đích |
|---|---|
| Hiện dần khi cuộn (0.6s, so le 70ms) | Dẫn mắt đọc theo thứ tự; trang không khô cứng |
| Nút nhấc 2px khi rê, ép xuống khi bấm | Báo "bấm được", phản hồi tức thì |
| Mũi tên trên nút chính trượt phải | Gợi hướng "đi tiếp" |
| Thẻ nhấc 4px, viền ấm lên khi rê | Báo thẻ có tương tác |
| Thanh trên đổ bóng khi cuộn | Báo thanh đang dính phía trên nội dung |
| Thanh CTA dưới điện thoại trượt lên sau phần đầu | Giữ hành động trong tầm ngón cái, không che màn hình đầu |
| Dấu cộng xoay thành dấu nhân ở hỏi đáp | Báo đang mở/đóng |
| Đếm số `data-dem` | Chỉ cho con số **thật** chủ đã cung cấp |
| Tắt hết khi hệ điều hành bật "giảm chuyển động" | Quyền của người dùng, bắt buộc |

## Luật thời gian và đường cong

- Phản hồi khi bấm, rê: **120 đến 200 ms**. Hiện nội dung: **400 đến 700 ms**. Quá 800 ms là chậm, khách tưởng trang lỗi.
- Đường cong `cubic-bezier(.22,.8,.3,1)` (nhanh rồi chậm dần). Không dùng chuyển động tuyến tính cho thứ trượt.
- Chỉ chuyển `transform` và `opacity` (mượt, không giật). Không chuyển `width`, `height`, `top`, `left`, `margin`.
- Không chuyển động lặp vô hạn ở nơi khách đang đọc (nhấp nháy, xoay, nảy). Ngoại lệ: một chấm "đang trực tuyến" nhỏ, chậm.

## Không làm

- Chữ chạy ngang liên tục, banner trượt tự động che nội dung.
- Video nền tự phát (nặng, ngốn pin, thường là thừa). Nếu thật cần: ≤ 1.5 MB, không tiếng, có ảnh thay thế, tắt trên điện thoại.
- Hiệu ứng "kính mờ" (glass) khắp nơi: chỉ thanh trên là đủ.
- Hiệu ứng thị sai (parallax) trên điện thoại.
- Đếm ngược giả, thanh "N người đang xem trang này" giả, thông báo "vừa có người mua" giả. Đây là **bịa bằng chứng**, trái luật của skill dựng web, và dễ mất lòng tin.
- Popup thoát trang (exit intent) che form.

## Bóng, bo góc, viền

- Bo góc theo biến `--radius` của chủ đề (6 đến 22px). Cùng một trang chỉ dùng **hai** cấp bo: lớn cho thẻ, nhỏ hơn 4 đến 6px cho nút và ô nhập.
- Bóng hai lớp: một lớp sát nhỏ, một lớp xa mờ. Có sẵn `--shadow-sm`, `--shadow-md`, `--shadow-lg`. Mỗi trang dùng tối đa ba cấp.
- Viền mảnh 1px màu `--line` cho thẻ trên nền trắng; trên nền màu dùng bóng thay viền.

## Trạng thái bắt buộc cho phần tử bấm được

Mỗi nút, liên kết, ô nhập phải có đủ: **mặc định, rê, bấm, tiêu điểm bàn phím (focus), vô hiệu (disabled), đang tải**. Viền tiêu điểm dày ≥ 2px, tương phản ≥ 3:1 (đã có `:focus-visible`). Không bao giờ `outline: none` mà không thay bằng viền khác.

## Form: chỗ quyết định chuyển đổi

- Càng ít ô càng tốt: tên, số điện thoại, một lựa chọn. Hỏi thêm sau khi đã có số.
- Nhãn đặt **trên** ô, không chỉ dùng chữ mờ bên trong (placeholder biến mất khi gõ).
- Báo lỗi bằng chữ cạnh ô, nói cách sửa ("Số điện thoại cần 10 số, bắt đầu bằng 0"), không chỉ đổi viền đỏ.
- Nút gửi nói điều khách nhận ("Gửi cho tôi bản gợi ý"). Đang gửi: nút khóa và đổi chữ.
- Dòng an tâm dưới nút ("Thông tin được giữ kín") đã được script thêm tự động; sửa chữ nếu cần cho đúng thực tế (chỉ hứa điều làm được).
- Gửi xong: thông báo rõ và chuyển sang trang cảm ơn. Không để khách tự đoán đã gửi chưa.

## Nội dung động

Thông báo, trạng thái tải, ô trống: viết bằng tiếng Việt thân thiện, nói rõ chuyện gì đang xảy ra và làm gì tiếp. Không để chữ tiếng Anh kỹ thuật ("Error 500", "undefined") hiện ra với khách.
