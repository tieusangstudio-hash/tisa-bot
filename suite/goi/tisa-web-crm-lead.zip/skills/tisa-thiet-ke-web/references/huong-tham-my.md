# Chọn hướng thẩm mỹ

Mục tiêu: trang **trông đúng là của ngành này, của doanh nghiệp này**, không trông như mẫu có sẵn. Mẫu có sẵn thì khách đã thấy cả trăm lần và không còn tin.

## Năm câu tự hỏi trước khi chọn

1. Khách mua vì **tin** (bảo hiểm, y tế, xây nhà), vì **thích** (thời trang, quà), hay vì **tiện** (dịch vụ, ứng dụng)? Tin thì chọn màu trầm, nhiều khoảng trắng, chữ rõ. Thích thì nhiều hình, màu có cảm xúc. Tiện thì gọn, nút to.
2. Giá cao hay thấp? Giá cao cần khoảng trắng rộng, chữ có chân (serif), ít màu. Giá thấp cần rõ ràng, nhiều thông tin, nút nổi.
3. Khách tuổi nào, nam hay nữ nhiều hơn? Người trẻ chịu được bo góc lớn, màu mạnh. Người lớn tuổi cần chữ lớn hơn, tương phản cao, bớt hiệu ứng.
4. Đối thủ gần nhất trông thế nào? Làm **khác một điểm dễ nhớ** (màu, ảnh, giọng chữ), không làm đẹp hơn cùng kiểu.
5. Có gì **thật** để khoe (công trình, ảnh khách, giấy phép)? Có thì bố cục xoay quanh nó.

## 8 chủ đề có sẵn

Chọn bằng `--chu-de <id>`. Mỗi chủ đề đã kiểm tương phản AA, đã kiểm phông có đủ dấu tiếng Việt.

| id | Hợp ngành | Cảm giác | Phông tiêu đề / nội dung | Bo góc |
|---|---|---|---|---|
| `tin-cay-xanh` | Tài chính, bảo hiểm, giáo dục, tư vấn, B2B | Chuyên gia, đáng tin, hiện đại | Plus Jakarta Sans / Be Vietnam Pro | vừa |
| `am-ap-dat` | Nội thất, ẩm thực, cà phê, quà tặng, homestay | Ấm, thủ công, gần gũi | Lora / Be Vietnam Pro | vừa |
| `sang-trong-den-vang` | BĐS cao cấp, thẩm mỹ viện, trang sức, hạng sang | Sang, tiết chế, thanh lịch | Playfair Display / Be Vietnam Pro | nhỏ |
| `tuoi-tre-nang-dong` | Khóa học, kỹ năng, bán lẻ online, sự kiện | Trẻ, vui, tràn năng lượng | Plus Jakarta Sans / Be Vietnam Pro | lớn |
| `xanh-la-suc-khoe` | Y tế, phòng khám, thực phẩm sạch, nông sản | Sạch, an toàn, tươi | Nunito / Be Vietnam Pro | vừa |
| `hong-nu-tinh` | Mỹ phẩm, spa, thời trang nữ, mẹ và bé, hoa, cưới | Mềm, nữ tính, tinh tế | Playfair Display / Be Vietnam Pro | lớn |
| `cong-nghe-toi` | Phần mềm, AI, ứng dụng, tự động hóa, điện tử | Sắc, hiện đại, kỹ thuật | Space Grotesk / Inter | nhỏ vừa |
| `nha-dat` | BĐS nhà phố, xây dựng, sửa nhà, môi giới, vật liệu | Vững chãi, rõ ràng, đáng tin | Montserrat / Be Vietnam Pro | nhỏ |

Phân vân giữa hai chủ đề: gắn lần lượt cả hai, chụp màn hình, **cho anh chị chọn bằng mắt**, đừng tự quyết.

## Thương hiệu riêng (khi anh chị đã có logo, màu)

Màu thật của doanh nghiệp thắng chủ đề có sẵn. Cách làm:

1. Lấy màu chủ đạo từ logo (mã `#rrggbb`). Đặt vào `lead/styles.css` biến `--primary`. Nếu màu quá sáng để làm nền hero tối, **đậm nó xuống** (giữ sắc độ, giảm độ sáng) thành `--primary-deep`.
2. Chọn một màu nhấn ấm hoặc tương phản với màu chủ đạo cho nút (`--accent`). Quy tắc nhanh: chủ đạo xanh lạnh thì nhấn cam hoặc vàng; chủ đạo đỏ, nâu, cam thì nhấn kem hoặc xanh ngọc đậm; chủ đạo đen thì nhấn vàng đồng.
3. Đặt `--on-accent` là chữ đậm gần đen hoặc trắng, **tính tương phản chữ trên nút ≥ 4.5:1**. Tính nhanh: tỉ lệ = (L1 + 0.05) / (L2 + 0.05) với L là độ sáng tương đối, hoặc dùng `soat-trang.mjs` (nó cũng kiểm các cặp chính).
4. `--accent-deep` là bản **đậm hơn** của màu nhấn, dùng làm chữ nhấn trên nền trắng, phải ≥ 4.5:1 với trắng.
5. Nền nhạt `--tint` là màu chủ đạo pha 92% trắng; `--tint-warm` là màu nhấn pha 90% trắng.
6. Vẫn chọn chủ đề gần nhất để lấy phông và bo góc, rồi ghi đè 5 biến màu trong `styles.css`.

## Phông chữ

- Tối đa **hai họ**: một cho tiêu đề (có cá tính), một cho nội dung (dễ đọc). Một họ cho cả hai cũng rất tốt.
- Chỉ dùng phông có tiếng Việt đầy đủ: Be Vietnam Pro, Plus Jakarta Sans, Lexend, Nunito, Quicksand, Montserrat, Inter, Space Grotesk, Playfair Display, Lora, Merriweather, Roboto Slab, Noto Serif. **Tránh** phông chỉ có Latin cơ bản (dấu bị rơi sang phông khác nhìn xấu và lệch dòng).
- Cỡ chữ nội dung 16 đến 18px, dòng cao 1.6 đến 1.7, mỗi dòng không quá 70 ký tự. Tiêu đề lớn cao dòng 1.15 đến 1.25.
- Chữ in hoa chỉ cho nhãn ngắn (eyebrow), không cho cả đoạn.

## Màu và khoảng cách

- **60 / 30 / 10:** 60% nền trung tính, 30% màu chủ đạo, 10% màu nhấn. Màu nhấn chỉ dành cho **hành động** (nút, chỗ cần chú ý). Dùng màu nhấn khắp nơi thì không còn gì nổi.
- Nền trắng và nền nhạt đan xen giữa các khối để mắt nghỉ; nền tối dành cho màn hình đầu và lời mời cuối.
- Khoảng trắng là sang. Khối cách khối 64 đến 96px trên máy tính, 44 đến 56px trên điện thoại. Cái gì cùng ý thì đứng gần, khác ý thì đứng xa.
- Bóng đổ nhẹ, hai lớp, độ mờ lớn. Bóng đậm và cứng trông rẻ.

## 12 dấu hiệu "trang làm vội, nhìn là biết" cần tránh

1. Nền gradient tím xanh rực làm nền cả trang.
2. Mọi thẻ bo góc và đổ bóng giống nhau, xếp ba cột đều tăm tắp, không có điểm nhấn.
3. Biểu tượng emoji làm biểu tượng tính năng.
4. Ảnh stock người cười bắt tay, ảnh người nước ngoài cho dịch vụ trong nước.
5. Mọi tiêu đề đều lớn như nhau, không có thứ bậc.
6. Chữ xám nhạt trên nền trắng (đẹp nhưng không đọc được).
7. Nút phụ và nút chính cùng màu, khách không biết bấm cái nào.
8. Cả trang chỉ có chữ, không có một ảnh thật nào.
9. Hiệu ứng nhảy, xoay, nhấp nháy không phục vụ việc gì.
10. Banner cookie, popup, chat bật ra che màn hình đầu.
11. Số liệu to (10.000+ khách, 99% hài lòng) mà không có nguồn.
12. Chữ "Gửi", "Submit", "Click here" trên nút. Nút phải nói điều khách nhận được.

## Ghi lại để nhất quán

Sau khi chốt, ghi vào `lead/THIET-KE.md`: chủ đề, màu chủ đạo, màu nhấn, hai phông, bo góc, phong cách ảnh, các điều "không làm". Lần sau ai sửa cũng đọc cái này trước.
