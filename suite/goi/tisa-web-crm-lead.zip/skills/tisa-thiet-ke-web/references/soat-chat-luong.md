# Soát chất lượng trước khi cho xem và trước khi đăng

Chạy theo thứ tự. Mỗi mục "không đạt" thì sửa rồi soát lại mục đó.

## A. Tự động

`node <skill>/scripts/soat-trang.mjs --thu-muc <lead>` (thêm `--dang` cho bản sắp đăng thật). Script kiểm: ngôn ngữ, viewport, tiêu đề, mô tả, một thẻ h1, alt và kích thước ảnh, dung lượng ảnh, form còn đủ ô, chữ mẫu còn sót, noindex, đếm ngược giả, liên kết hỏng, crmEndpoint còn localhost, tương phản màu chính.

## B. Bằng mắt: ba cỡ màn hình (bắt buộc)

Chụp ba cỡ: **390x844** (điện thoại), **768x1024** (máy tính bảng), **1280x800** (máy tính). Dùng trình duyệt TISA hoặc công cụ chụp có sẵn: mở trang, đặt kích thước cửa sổ, chụp, **tự xem ảnh**.

Với mỗi ảnh, trả lời:

1. Nhìn 5 giây: biết trang này cho ai, được gì, bấm đâu không?
2. Có chỗ nào chữ bị cắt, chồng lên nhau, tràn khỏi khung, nhỏ hơn 14px?
3. Có thanh cuộn ngang? (điện thoại: tuyệt đối không)
4. Nút chính nổi nhất màn hình? Có đủ lớn để bấm bằng ngón cái?
5. Ảnh có đúng ngành, rõ nét, không méo, không vỡ?
6. Chữ trên ảnh/nền màu đọc được không?
7. Khoảng cách các khối đều và thoáng? Có khối nào dính sát khối khác?

Kiểm thêm: cuộn đến cuối trang (hiệu ứng hiện dần có làm khối nào biến mất không), bấm thử nút chính, gõ thử form (bàn phím điện thoại có che ô đang gõ không).

## C. Truy cập (ai cũng dùng được)

- Chữ thường tương phản ≥ 4.5:1, chữ to (≥ 24px hoặc ≥ 19px đậm) ≥ 3:1. Không chỉ dùng màu để báo ý (lỗi đỏ phải kèm chữ).
- Đi bằng phím Tab: có viền tiêu điểm thấy rõ, thứ tự hợp lý, không bị kẹt.
- Mọi ảnh có alt đúng; mọi ô nhập có nhãn; nút có chữ (nút chỉ có biểu tượng phải có `aria-label`).
- Thử bật "giảm chuyển động" trong hệ điều hành: trang vẫn đủ nội dung, không còn hiệu ứng.
- Thu phóng chữ 200%: không vỡ bố cục.

## D. Tốc độ (khách dùng 4G và máy cũ)

Ngưỡng cần đạt trên đường mạng chậm: nội dung đầu hiện **dưới 2.5 giây**, không nhảy bố cục khi tải, bấm được phản hồi ngay.

- Tổng dung lượng màn hình đầu < 1 MB (ảnh là chính). Tổng trang < 2.5 MB.
- Tối đa 2 họ phông, 3 độ đậm mỗi họ (đã có `display=swap`).
- Ảnh đầu trang không `lazy`; ảnh còn lại `lazy`. Mọi ảnh có `width`/`height`.
- Không thêm thư viện JS lớn (jQuery, slider, popup) cho việc CSS làm được.
- Nếu có công cụ đo (Lighthouse trong Chrome, PageSpeed Insights khi đã đăng), mục tiêu điểm trên 90 ở Hiệu suất, Truy cập, SEO. Đo trên điện thoại, không chỉ máy tính.

## E. Tìm kiếm và chia sẻ

- `<title>` 30 đến 60 ký tự, có từ khóa khách tìm và tên thương hiệu. `meta description` 80 đến 160 ký tự, viết như lời mời.
- Mỗi trang đúng một `<h1>`. Thứ tự h2, h3 không nhảy cấp.
- `og:title`, `og:description` (script đã tự thêm), `og:image` 1200x630 (thêm khi đã có tên miền và ảnh).
- Bỏ `meta robots noindex` **chỉ khi** đăng thật và đã soát xong. Đưa trang cảm ơn **giữ noindex**.
- Doanh nghiệp địa phương: ghi rõ tên, địa chỉ, số điện thoại ở chân trang đúng một kiểu viết, trùng với Google Business, Fanpage.

## F. Chuyển đổi và niềm tin

- Có đúng **một** hành động chính trên mỗi trang, nút cùng một chữ ở mọi chỗ.
- Form ≤ 4 ô. Có chữ giải thích sau khi gửi sẽ có chuyện gì.
- Có thông tin liên hệ thật (số điện thoại, địa chỉ hoặc khu vực), có trang chính sách (quyền riêng tư), có tên pháp lý ở chân trang khi bán hàng.
- Mọi con số, cam kết, cảm nhận trên trang **là thật** và chủ đã xác nhận. Còn chỗ giả định thì ghi "(giả định)" rõ ràng và liệt kê cho chủ.
- Gửi thử form một lần: khách mẫu vào CRM đúng, rồi dọn dữ liệu thử.

## G. Trước khi đăng thật (chỉ khi chủ yêu cầu)

1. `soat-trang.mjs --dang` sạch LỖI.
2. Đổi mật khẩu CRM mặc định, đổi `crmEndpoint` sang địa chỉ công khai, gửi thử lại form.
3. Xóa `noindex` ở Lead Page và Sale Page; giữ ở trang cảm ơn.
4. Thêm `og:image`, kiểm bản chia sẻ bằng cách dán link vào Zalo/Messenger của chính chủ.
5. Hỏi chủ duyệt lần cuối, rồi mới đăng (theo `tisa-web-crm-lead`, `references/xuat-ban-va-ket-noi.md`).

## Báo cáo cho chủ (ngắn gọn, nói thật)

"Em đã chọn chủ đề X vì Y. Điểm mạnh của trang: …. Còn lại cần anh chị: ảnh thật, số Zalo, giá thật, xác nhận cam kết. Em đã soát: điện thoại, máy tính, tốc độ, truy cập. Chưa kiểm được: điểm đo thật trên mạng (chỉ đo được sau khi đăng)." Không hứa tăng bao nhiêu phần trăm chuyển đổi; chỉ nói cách đo (lượt vào trang so với số khách trong CRM).
