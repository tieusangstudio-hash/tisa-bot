# Làm đẹp phần CRM mà không phá logic

CRM là công cụ làm việc hằng ngày của chủ và nhân viên: **rõ, nhanh, dễ nhìn quan trọng hơn đẹp lộng lẫy**. Giao diện CRM chỉ làm ở mức thương hiệu và trang chủ; không viết lại ứng dụng, không đổi đăng nhập, không đổi logic tiền, không đổi tên nội bộ (`courses`, `lessons`, `enrollments`). Xem `crm/AGENTS.md` và `tisa-web-crm-lead/references/tuy-bien.md` trước.

## Việc nên làm (an toàn)

1. **Thương hiệu:** sửa `crm/template/business.json` (tên, câu định vị, ba màu `primary`, `accent`, `secondary`) rồi `node scripts/doi-thuong-hieu.mjs --apply`. Dùng **cùng màu** với Lead Page để khách đi từ trang này sang trang kia thấy một thương hiệu.
2. **Logo:** thay `crm/client/public/demo/logo.svg` và `crm/client/src/assets/receipt-logo.svg` bằng logo thật (SVG, nền trong suốt).
3. **Trang chủ CRM:** viết lại tiêu đề, câu phụ, ba thẻ trong `HomeHero.tsx` theo ngành. Ảnh sản phẩm: thay `p1.svg` đến `p6.svg` hoặc trỏ `image` trong `demo.json` tới ảnh thật.
4. **Chữ ngành mẫu còn sót** (`máy lọc`, `robot`, `lắp đặt`): thay đúng nghĩa.
5. **Ô trống và thông báo:** viết bằng tiếng Việt thân thiện, nói rõ làm gì tiếp ("Chưa có khách nào. Khi có người để lại số ở Lead Page, họ hiện ở đây.").

## Việc không làm

- Không đổi cấu trúc dữ liệu, tên trường, đường dẫn API, thuộc tính form mà Lead Page gửi vào.
- Không thêm thư viện giao diện lớn vào CRM. Không đổi phông toàn CRM sang phông có thể thiếu dấu tiếng Việt.
- Không đổi màu **trạng thái** (thành công xanh, lỗi đỏ, cảnh báo vàng): nhân viên dựa vào đó để làm việc.
- Không thêm hoạt ảnh trong bảng dữ liệu, danh sách khách.

## Nguyên tắc cho giao diện làm việc

- Bảng dữ liệu: chữ ≥ 14px, dòng cao 40 đến 48px, hàng xen kẽ nền rất nhạt, cột quan trọng (tên, số điện thoại, trạng thái) bên trái.
- Số điện thoại bấm được để gọi (`tel:`), Zalo mở bằng `https://zalo.me/<số>`.
- Mỗi màn hình có một hành động chính rõ.
- Chạy trên điện thoại: chủ thường xem CRM ngoài đường. Kiểm tra ở 390px: bảng cuộn ngang trong khung riêng, không làm vỡ cả trang.
- Sau khi sửa: `npm run check`, `npm run test:system` trong thư mục `crm`, rồi chạy lại demo và chụp trang chủ, danh sách khách, trang chi tiết.
