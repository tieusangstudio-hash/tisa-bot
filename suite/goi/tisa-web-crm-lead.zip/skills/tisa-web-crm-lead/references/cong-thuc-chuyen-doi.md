# Công thức chuyển đổi

Mục tiêu: khách đọc xong thấy "đúng chuyện của mình, cách này hợp lý, làm ngay không rủi ro". Đây là khung viết rút từ các tác giả bán hàng kinh điển, không phải bảo đảm về con số.

## Nguồn công thức

| Tác giả, sách | Dùng để làm gì |
|---|---|
| Eugene Schwartz, *Breakthrough Advertising* (1966) | Năm mức nhận biết của khách. Cơ chế riêng: vì sao cách này khác |
| Alex Hormozi, *$100M Offers* (2021) | Phương trình giá trị: (kết quả mơ ước x độ tin sẽ đạt) / (thời gian chờ x công sức). Gói giá trị xếp từng phần |
| Russell Brunson, *DotCom Secrets*, *Expert Secrets* | Hook, Story, Offer. Câu chuyện nhận ra (Epiphany Bridge). Phá niềm tin sai |
| PAS, phổ biến trong copywriting trực tiếp, Dan Kennedy dùng nhiều | Vấn đề, xoáy sâu, giải pháp |
| AIDA, E. St. Elmo Lewis | Chú ý, quan tâm, mong muốn, hành động |
| David Ogilvy, *Ogilvy on Advertising* (1983); John Caples, *Tested Advertising Methods* | Tiêu đề nói lợi ích cụ thể, bán bằng thông tin |
| Claude Hopkins, *Scientific Advertising* (1923) | Cụ thể hơn chung chung, nêu lý do, đo bằng thử nghiệm |
| Joseph Sugarman, *The Adweek Copywriting Handbook* | Mỗi câu kéo người đọc sang câu sau |
| Gary Halbert, *The Boron Letters* | Chọn đúng người đang khát trước khi lo câu chữ |
| Jay Abraham | Đảo ngược rủi ro: người bán nhận rủi ro về mình |
| Robert Cialdini, *Influence* (1984) | Bằng chứng xã hội, thẩm quyền, khan hiếm thật, cam kết nhỏ |
| Daniel Kahneman, *Thinking, Fast and Slow* | Sợ mất mạnh hơn muốn được: nêu cái giá của việc để nguyên |
| BJ Fogg, *Tiny Habits* (B = MAP) | Làm hành động thật dễ: ít ô nhập, ít lý do chần chừ |

## Bốn việc làm trước khi viết

1. **Đoán mức nhận biết (Schwartz).** Khách chưa biết mình có vấn đề: mở bằng tình huống và hệ quả. Biết vấn đề, chưa biết cách giải: mở bằng nỗi đau và cách mới. Biết cách, chưa biết bạn: mở bằng điểm khác biệt. Đã biết bạn: mở bằng gói và giá. Quảng cáo lạnh thường rơi vào hai mức đầu.
2. **Viết một câu lời hứa:** làm được [kết quả cụ thể] trong [thời gian], không phải [việc họ ghét].
3. **Viết cơ chế riêng:** vì sao các cách cũ chưa ổn, cách này khác ở điểm nào. Một câu dễ nhớ, phải đúng với cách doanh nghiệp làm thật.
4. **Lấy lời khách:** ưu tiên đúng câu khách đã nói ở Câu 5 và Bộ Não.

## Lead Page: 8 khối của khung

Mục đích: đổi một lời mời có giá trị lấy số điện thoại. Không menu, không link ra ngoài, một hành động.

| Khối | Viết thế nào | Công thức |
|---|---|---|
| 1. Thanh trên | Logo và một nút | Một trang, một hành động |
| 2. Lời hứa và form | Dòng nêu đúng người, tiêu đề lời hứa, câu nói cách nhận, 3 thứ sẽ nhận. Form bên cạnh, tối đa 3 ô và ô đồng ý | Schwartz, Ogilvy, Hormozi, Fogg |
| 3. Đúng nỗi đau | 3 câu đúng lời khách, rồi một dòng về cái giá của việc để nguyên | PAS, Kahneman |
| 4. Cách nghĩ mới | Sai lầm phổ biến, cách nghĩ đúng, 3 ý ngắn, ảnh | Schwartz, Brunson |
| 5. Sau khi gửi | 3 bước rõ, nói rõ không bị ép mua | Giảm công sức trong phương trình giá trị |
| 6. Bằng chứng | Chỉ thật. Chưa có thì giữ ô viền đứt | Cialdini |
| 7. Hỏi đáp | Mỗi câu xử lý một lý do chưa để lại số: phí, bị làm phiền, bao lâu, khu vực | Xử lý từ chối |
| 8. Lời mời cuối | Nhắc lời hứa, cùng nút cũ, cuộn về form | AIDA |

Lời mời mạnh khi đủ: giải quyết một việc nhỏ cụ thể, có kết quả cầm được, biết trước thời gian, không phải mua gì.

## Sale Page: 12 khối của khung

Mục đích: khách đăng ký đặt một gói rõ giá. Nút đặt xuất hiện ở khối 1, 6 và 12, cùng một lời.

| Khối | Viết thế nào | Công thức |
|---|---|---|
| 1. Tiêu đề | Kết quả cụ thể, bỏ được việc họ ghét. Một câu phụ. Hai nút: đặt và xem gói | Schwartz, Ogilvy, Caples |
| 2. Đúng vấn đề | Một câu mở đúng tâm trạng, 3 câu lời khách, một dòng cái giá | PAS, Sugarman, Kahneman |
| 3. Câu chuyện | Chuyện thật: gặp gì, nhận ra gì, đổi cách làm thế nào. Chưa có thì giữ chỗ và hỏi chủ | Brunson |
| 4. Cơ chế khác biệt | Bảng cách thường làm và cách này | Schwartz |
| 5. Trước và sau | 4 dòng việc cũ đổi thành việc mới | Hormozi |
| 6. Gói giá trị | Từng phần có giá trị riêng bằng giá lẻ thật, tổng lẻ gạch đi, rồi giá gói, rồi nút | Hormozi |
| 7. Bằng chứng | Đặt sát sau giá. Chỉ thật | Cialdini |
| 8. Bảo đảm | Một cam kết cụ thể, có điều kiện, làm được thật | Jay Abraham |
| 9. Hợp và chưa hợp | Nói rõ ai nên, ai không nên | Halbert, tăng độ tin |
| 10. Lý do làm ngay | Giới hạn có thật. Không có thì xóa khối | Cialdini, Hormozi |
| 11. Hỏi đáp | Giá gồm gì, thu tiền thế nào, bao lâu, sau đó ra sao, để hỏi người nhà | Xử lý từ chối |
| 12. Đặt gói | Nhắc lời hứa, nói rõ sau khi bấm có gì, form ít ô | AIDA, Fogg |

## Viết tiêu đề

Viết ít nhất 5 phương án trong đầu, chọn câu cụ thể nhất. Khuôn dùng được:

- Biết đúng [điều cần biết] sau [thời gian], không phải [việc họ ghét]
- Có [kết quả] mà không phải [công sức lớn nhất]
- [Đúng người]: [lời hứa] trong [thời gian]
- Vì sao [cách phổ biến] chưa [kết quả], và cách [cơ chế mới]

Trên điện thoại tiêu đề nên gọn trong 5 dòng. Nói trong 5 giây: trang này cho ai, được gì, làm gì tiếp.

## Viết chữ

Câu ngắn, từ khách hay dùng, nói "bạn" nhiều hơn "chúng tôi", số cụ thể thật thay cho "nhiều", "tốt nhất", "hàng đầu", "uy tín". Bằng chứng đặt sát lời khẳng định. Nút nói việc khách nhận được ("Nhận phác đồ da của tôi"), không ghi "Gửi".

## Hàng rào bắt buộc

Không bịa cảm nhận, số khách, kết quả, chức danh, giải thưởng. Không đếm ngược giả, không "chỉ còn vài suất" khi không đúng. Không dọa bệnh tật, không hứa chữa khỏi hay hứa kết quả tuyệt đối, không nói xấu đối thủ đích danh. Sức khỏe, tài chính, làm đẹp: kiểm tra kỹ quy định quảng cáo của ngành và nền tảng. Kết quả khách hàng ghi kèm "tùy từng người và mức độ áp dụng" nếu là sản phẩm phụ thuộc người dùng.

## Soát trước khi cho xem

- [ ] Đọc 5 giây đầu biết cho ai, được gì, làm gì tiếp
- [ ] Tiêu đề có kết quả cụ thể, không dùng lại tiêu đề của ngành mẫu
- [ ] Không còn chữ về máy lọc nước hay NOVA, trừ khi ngành giả định là máy lọc nước
- [ ] Mọi giá, cam kết giả định đều ghi "(giả định)"
- [ ] Không có bằng chứng tự nghĩ ra
- [ ] Tổng lẻ của gói đúng bằng tổng các phần
- [ ] Giá và tên sản phẩm khớp giữa Sale Page, ô chọn của form và CRM
- [ ] Form gửi được và khách vào CRM
- [ ] Xem bản điện thoại rộng 375px: không tràn ngang, nút dễ bấm, nút dính không che form
- [ ] Không có ký tự gạch dài

## Sau khi có khách thật

Đo: lượt vào trang (công cụ quảng cáo hoặc analytics) so với số form trong CRM, rồi tỉ lệ từ form thành đơn. Mỗi lần chỉ đổi một thứ, ưu tiên tiêu đề, rồi lời mời, rồi giá trị gói. Thêm `?utm_source=...&utm_campaign=...` vào link quảng cáo, form tự ghi vào CRM.
