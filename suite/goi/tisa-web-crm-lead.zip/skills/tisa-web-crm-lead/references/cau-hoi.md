# Bộ câu hỏi

Hỏi lần lượt, mỗi lượt một câu, viết lời tự nhiên nhưng giữ đủ Gợi ý và Ví dụ. Cuối **mỗi** câu luôn thêm nguyên văn:

> Nếu chưa có thì anh chị cứ bỏ qua, em sẽ tạo giả định để làm demo trước, mình cập nhật sau.

Ví dụ trong file này chỉ để minh họa cách trả lời. Chọn ví dụ gần ngành của họ nếu đã biết ngành, không chép ví dụ vào trang.

## Câu 1. Muốn tạo web gì

"Anh chị muốn tạo web để bán sản phẩm hoặc dịch vụ gì?"

- Gợi ý: nói một câu là đủ: bán cái gì, cho ai. Bộ này gồm web CRM quản lý khách, Lead Page để lấy số điện thoại và Sale Page để bán một gói chính.
- Ví dụ: "Em làm spa da mặt cho phụ nữ văn phòng ở Đà Nẵng."
- Nếu bỏ qua: giữ ngành mẫu máy lọc nước của khung và nói rõ là ngành giả định.

## Câu 2. Dùng Bộ Não Thứ 2

"Anh chị có muốn em lấy thông tin từ Bộ Não Thứ 2 để dựng web không?"

- Gợi ý: Bộ Não Thứ 2 là kho hồ sơ doanh nghiệp anh chị đã lưu. Dùng thì em đỡ phải hỏi nhiều và nội dung sát thực tế hơn. Anh chị trả lời "có", "không" hoặc gửi đường dẫn thư mục.
- Ví dụ: "Có, thư mục nằm ở Desktop."

Nếu "có", tìm theo thứ tự rồi chỉ đọc phần liên quan:

1. Trong brain TISA BOT: `wiki/index.md`, `memory/MEMORY.md`, `Bo nao thu 2 - Desktop/index.md`, `05 - Van Phong AI/01 - Ho so/`.
2. Thư mục tên `Bộ Não Thứ 2`: `00-DOC-TRUOC.md`, `muc-luc.md`, `01-ho-so/01-ho-so-doanh-nghiep.md`, `02-san-pham-dich-vu.md`, `03-khach-hang-muc-tieu.md`, `04-thuong-hieu-noi-dung.md`, `05-muc-tieu-quy-tac-lien-he.md`, `03-tai-lieu-tho/`, `04-ket-qua/`.
3. Không thấy: hỏi đường dẫn một lần, vẫn không có thì báo chưa tìm thấy và hỏi tiếp bình thường.

Tìm được thì tóm tắt 3 đến 5 dòng đã lấy được gì, **bỏ qua những câu đã có đủ**, chỉ hỏi phần còn thiếu. Không đưa số điện thoại, email của khách từ Bộ Não lên web. Số liệu trong Bộ Não là mục tiêu thì không viết thành kết quả đã đạt.

## Câu 3. Thông tin doanh nghiệp

"Anh chị cho em tên doanh nghiệp, một câu định vị, số điện thoại, email và địa chỉ."

- Gợi ý: câu định vị là một câu nói doanh nghiệp giúp ai đạt được gì. Thiếu mục nào cứ để trống mục đó.
- Ví dụ: "Mộc Spa. Chăm da cho phụ nữ bận rộn, 45 phút mỗi tuần. 0900 000 000, moc@example.com, 12 Lê Lợi, Đà Nẵng."

## Câu 4. Sản phẩm và dịch vụ

"Anh chị đang bán những sản phẩm, dịch vụ nào? Mỗi món cho em tên, giá và một câu mô tả, có ảnh thì gửi luôn."

- Gợi ý: gửi danh sách, bảng tính hoặc đường dẫn đều được. Từ 1 đến 6 món là đẹp cho demo. Chưa chốt giá thì nói giá khoảng cũng được.
- Ví dụ: "Liệu trình cấp ẩm 5 buổi, 1.500.000đ, phục hồi da khô cho người làm máy lạnh."
- Nếu họ nói "em tự đề xuất" hoặc chưa có giá: đề xuất một mức hợp ngành, ghi "(giả định)" và đưa vào bảng chốt để họ sửa.

## Câu 5. Khách hàng của anh chị

"Khách hàng chính của anh chị là ai, họ đang khổ chuyện gì và mong điều gì? Họ hay nói câu nào lúc mới hỏi mua?"

- Gợi ý: câu này quyết định độ thuyết phục của cả trang. Càng dùng đúng lời khách nói càng tốt, dán nguyên tin nhắn khách cũng được (che tên và số điện thoại). Cũng cho em biết lý do khách thường chần chừ.
- Ví dụ: "Phụ nữ 28 đến 40, da khô sạm vì ngồi máy lạnh. Khách hay nói: đi spa hoài mà về đâu lại vào đó, với lại em không có thời gian."

## Câu 6. Lời mời của Lead Page

"Khách để lại số điện thoại thì nhận được gì ngay? Anh chị có sẵn món gì để mời không?"

- Gợi ý: nên là thứ có ích, tốn ít, giải quyết đúng một việc nhỏ: buổi tư vấn ngắn, bản đo kiểm, tài liệu một trang, báo giá nhanh. Càng cụ thể về kết quả và thời gian càng dễ có khách để lại số.
- Ví dụ: "Soi da miễn phí 15 phút rồi gửi phác đồ qua Zalo."

## Câu 7. Gói bán của Sale Page

"Sale Page sẽ bán gói nào? Giá bao nhiêu, gồm những gì, có tặng kèm hay cam kết gì không?"

- Gợi ý: chọn một món chính. Liệt kê từng phần trong gói với giá mua lẻ thật, em sẽ xếp thành gói giá trị. Bảo đảm chỉ nêu điều anh chị làm được thật, kèm điều kiện.
- Ví dụ: "Liệu trình 5 buổi 1.500.000đ, tặng một lần soi da trị giá 200.000đ. Không hợp ở buổi đầu thì hoàn tiền buổi đó."
- Nếu họ nói "em tự đề xuất": ghép gói từ các món ở Câu 4, giá gói không được cao hơn tổng giá lẻ, ghi "(giả định)". Không tự thêm quà tặng có giá trị hay bảo đảm.

## Câu 8. Bằng chứng thật

"Anh chị có cảm nhận khách, ảnh trước sau, số khách đã phục vụ, giấy chứng nhận, báo chí nào không?"

- Gợi ý: chỉ dùng thứ có thật và khách đã đồng ý. Có câu chuyện vì sao anh chị làm nghề này thì kể luôn, câu chuyện thật bán rất tốt.
- Ví dụ: "Có 3 tin nhắn cảm ơn đã xin phép khách, và tôi từng bị hỏng da nên mới học nghề."
- Lưu ý khi bỏ qua: phần này em không tự nghĩ ra. Em để ô trống đúng chỗ, anh chị bổ sung sau.

Câu nhắc cuối câu này đổi thành: "Nếu chưa có thì anh chị cứ bỏ qua, em sẽ để ô trống cho demo trước, mình cập nhật sau. Phần bằng chứng em không tạo giả định vì phải là thật."

## Câu 9. Hình ảnh thương hiệu

"Anh chị có logo, màu thương hiệu và ảnh thật không? Thích phong cách nào?"

- Gợi ý: gửi tệp logo, mã màu hoặc mô tả bằng lời, kèm một trang web anh chị thấy đẹp nếu có. Ảnh thật của sản phẩm, cửa hàng, con người luôn tốt hơn ảnh minh họa.
- Ví dụ: "Xanh lá nhạt, tối giản, nhìn sạch sẽ, nhẹ nhàng."

## Câu 10. Hành động chốt

"Khi khách đã quan tâm, anh chị muốn khách làm gì tiếp theo? Có Zalo, Fanpage hay thời gian phản hồi cam kết không?"

- Gợi ý: một trang chỉ nên có một hành động chính. Mặc định bộ này là khách điền form và CRM ghi lại, rồi anh chị hoặc bot gọi lại. Nêu thời gian gọi lại mà đội của anh chị làm được thật.
- Ví dụ: "Điền form, trong 2 giờ làm việc em gọi lại. Zalo 0900 000 000."
- Nếu họ không nêu thời gian gọi lại: viết "sẽ gọi lại cho bạn", không ghi số giờ, và ghi vào bảng chốt là chờ họ xác nhận.

Sau câu này chuyển sang Bước 3 trong SKILL.md.
