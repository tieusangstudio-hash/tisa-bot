# Nối chatbot Zalo / Facebook vào CRM

Nói với học viên: "Em sẽ kiểm tra máy, nối CRM rồi dùng một khách thử để xem dữ liệu có vào đúng chỗ không. Em tự làm phần kỹ thuật; anh chị chỉ cần chọn khi có câu hỏi."

## 1. Kiểm tra trước khi nối

- Kiểm tra Node bằng `node -v`, cần 22.13+. Kiểm tra gói `tisa.web-crm-lead` phiên bản 2.0.0 trong trang Gói và sự hiện diện của skill này, connector `tisa-crm`, plugin `crm-zalo` và `crm-chatbot-leads`.
- Nếu chưa cài: hướng dẫn trang Gói, Cài từ tệp .zip, chọn ZIP v2, đọc thông tin rồi bấm Cài. Không ghi vào thư mục brain của người khác.
- Tìm công cụ `crm_chatbot_status`. Nếu thiếu, xem gói có đang bật không ở trang Gói. Nếu giao diện yêu cầu chủ bật plugin riêng: vào **Công cụ / Plugins**, tìm **Data chatbot vào CRM**, gạt **Bật**. Plugin thuộc gói có thể được quản lý bằng công tắc cả gói ở trang Gói, làm theo thông báo giao diện. Không báo plugin đã bật khi chưa thấy công cụ.
- Dùng `crm_setup_status` kiểm tra phần CRM/Zalo cũ. Việc nhận data chatbot không yêu cầu bật tự động kết bạn, nhắn tin của crm-zalo.

## 2. Chạy web, sinh khóa và nối

Tự xác định thư mục CRM đã giải nén. Nếu chưa có, dùng `crm_unpack_source`, hoặc giải nén hai tệp nguồn vào thư mục mới theo SKILL.md. Không ghi đè CRM có dữ liệu.

1. Chạy `node scripts/demo-local.mjs --background` trong `crm`. Đọc `.local/demo.log` nếu lỗi. Dùng đúng cổng lệnh trả về.
2. Tạo khóa bằng cách đọc `.local/bootstrap-token` vào biến môi trường của tiến trình, chạy `node scripts/sites-bootstrap.mjs http://localhost:3000 --chatbot-key`. Ví dụ shell trên máy:
   ```sh
   BOOTSTRAP_TOKEN="$(cat .local/bootstrap-token)" node scripts/sites-bootstrap.mjs http://localhost:3000 --chatbot-key
   ```
   Với CRM trên mạng, dùng bootstrap secret của chính học viên và URL HTTPS thật. Không dùng token của bản local cho bản online. Nếu bootstrap secret đã xóa khỏi hosting, chủ phải đặt lại tạm để sinh khóa rồi gỡ đi.
3. Lệnh lưu khóa vào `~/.config/tisa-crm/chatbot.env`, quyền chỉ chủ máy đọc. `TISA_CRM_CONFIG_DIR` có thể đổi thư mục cấu hình; phải dùng cùng giá trị cho bootstrap và tiến trình TISA BOT. Không đọc nội dung file vào chat, không dán khóa vào kịch bản hay mã web, không đưa file vào ZIP/Git. Chỉ SHA-256 được lưu trong DB riêng của CRM.
4. Gọi `crm_chatbot_connect` với `crm_url` bằng đúng URL gốc trên. Công cụ tự đọc khóa, lưu cấu hình riêng trong data_dir của plugin và GET thử. Gọi tiếp `crm_chatbot_status`; chỉ khi trả OK mới báo đã nối.
5. Nếu HTTP 401: sinh lại khóa đúng CRM rồi nối lại. Nếu không kết nối: kiểm tra web đang chạy, URL/cổng và mạng. Plugin dùng User-Agent TISA-BOT/1.0. Nếu 403 vẫn xuất hiện, kiểm tra tường lửa của hosting; không tự tắt bảo vệ.

Nói đơn giản: "Khóa này giống chìa riêng để chatbot ghi khách vào web của anh chị. Em đã lưu kín trên máy, không cần anh chị chép vào chat."

## 3. Xin phép sửa kịch bản chatbot

Hỏi từng câu: "Anh chị muốn nối chatbot Fanpage hay Zalo nào vào CRM này? Em có thể thêm mục Lưu khách vào CRM vào kịch bản của chatbot đó, anh chị đồng ý không?"

Chỉ sửa sau khi chủ đồng ý và xác định đúng chatbot. Đọc kịch bản hiện tại, sao lưu, thêm mục dưới đây phù hợp với sản phẩm của học viên; giữ các hướng dẫn tư vấn khác. Không tự bật gửi tin hoặc gửi tin thử cho khách. Nếu không có quyền sửa, chỉ rõ nơi chủ cần thêm và báo chưa áp dụng.

### Mẫu mục thêm vào kịch bản

```markdown
## Lưu khách vào CRM
- Khi khách cung cấp tên cùng SĐT hoặc email, gọi crm_push_lead với channel đúng zalo/facebook, external_id là mã hội thoại nếu có. Không đoán số điện thoại.
- Điền name, phone/email, interest, concerns, disc (D/I/S/C: lý do từ hội thoại), strategy và summary. Tool tự lấy tin nhắn gốc trong kho hội thoại, không cần tự chép transcript.
- Bắt buộc tự đánh giá potential là số nguyên 1-4 và potential_reason là một câu có dẫn chứng. Đây là đánh giá của bot; sale chỉ xem.
- Khách có thông tin mới thì gọi lại để cập nhật theo SĐT, không tạo bản trùng.
- KHÔNG nói với khách là đã lưu vào CRM. Công cụ lỗi thì vẫn tư vấn bình thường, không nhắc lỗi kỹ thuật với khách; báo chủ qua luồng nội bộ đã được cho phép.
```

| Mức | Nhãn | Tiêu chí dựa trên hội thoại |
| --- | --- | --- |
| 4 | Rất nóng | Hỏi giá/lịch/cách thanh toán, sẵn sàng chốt hoặc nói đã cọc. Không tự xác nhận đã thu tiền. |
| 3 | Nóng | Nhu cầu rõ, còn cân nhắc giá, thời gian hoặc người nhà. |
| 2 | Ấm | Quan tâm, còn tìm hiểu, trả lời ít. |
| 1 | Lạnh | Hỏi qua, chưa có nhu cầu rõ hoặc im lặng. |

## 4. Chạy thử và dọn sạch

Tự làm qua công cụ và trình duyệt nếu có. Nếu thiếu trình duyệt, nhờ chủ kiểm tra màn hình và ghi rõ phần chưa tự nhìn thấy.

1. Gọi `crm_push_lead` với name `TEST TISA BOT XOA`, phone `0900000001`, channel `zalo`, summary `Dữ liệu kiểm thử, cần xóa`, potential `4`, potential_reason `Khách thử hỏi cách thanh toán`, transcript gồm hai tin `{from:"Khách",text:"Tôi muốn xem sản phẩm NOVA"}` và `{from:"Page",text:"Đây là hội thoại thử"}`. Nếu có hội thoại thật trong ngữ cảnh, tool ưu tiên kho gốc. Chạy trong phiên chủ kiểm thử, không trong hội thoại khách thật.
2. Mở `/admin?section=data-zalo-fb`, tìm số thử. Kiểm bảng đủ cột, mở Hồ sơ, Tiềm năng AI chỉ xem, tab Tin nhắn gốc có bong bóng Khách/Page. Gửi lại SĐT `+84 900 000 001`, xác nhận chỉ một khách và cùng id.
3. Mở `/admin?section=chatbot-sales`, tạo `SALE TEST XOA`, KPI 50.000.000đ, hoa hồng 10%, không điền số liên hệ thật. Gán sale cho khách thử.
4. Tab Chốt đơn: khóa `KHÓA TEST CRM XÓA`, số tiền 4.900.000đ, ngày hôm nay. Kiểm báo cáo sale đúng tháng: doanh thu 4.900.000đ, KPI 9,8%, hoa hồng 490.000đ. Chọn thời gian trong Data Zalo / FB, kiểm 1 data, 1 chốt và CSV khi lọc đúng khách thử.
5. Xóa khách thử bằng `DELETE /api/chatbot-leads?id=<id vừa tạo>` với Bearer đọc kín từ chatbot.env. API chỉ cho xóa đúng tên và SĐT thử trên. Đơn/gán sale tự xóa theo. Xóa sale thử qua giao diện sau đó; kiểm GET không còn khách, doanh thu/hoa hồng trở lại mức trước thử. Không dùng DELETE hoặc SQL để dọn khách thật.
6. Báo từng mục đạt/chưa thử kèm kết quả quan sát. Không suy luận OK từ việc chỉ mở được trang.

## 5. Đưa lên mạng và bàn giao

Giữ quy trình `xuat-ban-va-ket-noi.md`. Chỉ xuất bản sau khi học viên yêu cầu. Trước dữ liệu thật, đổi mật khẩu admin/123456, bỏ DEMO_ADMIN_LOGIN, dùng DB mới riêng và thay thông tin NOVA bằng thông tin đã được chủ chốt. Khi đổi URL sang web online: sinh khóa trên CRM online, gọi connect và status lại, chạy thử và xóa khách thử lại.

Nói rõ: thử local không chứng minh đã nhận được tin nhắn Zalo/Facebook thật. Chưa thử trên máy học viên, tài khoản/kênh thật, hosting thật thì ghi chưa thử. Không gửi tin cho ai để kiểm thử khi chưa được chỉ định.
