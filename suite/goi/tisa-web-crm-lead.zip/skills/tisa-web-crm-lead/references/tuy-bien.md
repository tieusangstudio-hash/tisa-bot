# Sửa khung theo doanh nghiệp

Đọc `crm/AGENTS.md` trước. Tên nội bộ giữ nguyên: `courses` là sản phẩm và dịch vụ, `lessons` là tài liệu, `enrollments` là quyền sở hữu, `/learn` là tài khoản khách. Không viết lại app, không đổi đăng nhập hay logic tiền. Không đưa các từ học viên, khóa học lên giao diện trừ khi doanh nghiệp thật sự dạy học.

Đường dẫn dưới đây tính từ thư mục đã giải nén, gồm `crm/` và `lead/`.

## CRM

1. `crm/template/business.json`: `name`, `tagline`, `description`, `phone`, `address`, `supportEmail`, `colors`. Giữ `siteUrl` và `leadOrigins` như cũ khi còn chạy trên máy. `ownerEmail` chỉ đổi cùng lúc với chủ thật, trước khi tạo dữ liệu.
2. Áp thương hiệu lên màn hình: `node scripts/doi-thuong-hieu.mjs` để xem, `node scripts/doi-thuong-hieu.mjs --apply` để đổi. Lệnh đổi chữ NOVA viết hoa, câu định vị, ba màu `primary`, `accent`, `secondary` lấy từ `business.json`, và vẽ lại logo mẫu thành chữ cái đầu của tên; sửa `business.json` rồi chạy lại được nhiều lần. Các màu nền nhạt phụ giữ nguyên. Không đụng tên trong mã. Đổi xong chạy lại `npm run build` hoặc tắt và chạy lại demo.
3. `crm/database/demo.json`: `categories`, `courses` (`slug`, `title`, `description`, `category`, `price`, `info`, `image`, `docs`), `leads`. Tên `course` của khách mẫu phải trùng `title` của một sản phẩm. Muốn dữ liệu mới có hiệu lực phải chạy `--reset`. Giữ ít nhất 2 sản phẩm, và ít nhất 1 sản phẩm có `docs`, nếu không `test:system` sẽ báo lỗi. Bỏ chữ "(mẫu)" trong tên khi tên đã là của họ, đơn mẫu tự lấy giá theo 2 sản phẩm đầu.
4. Ảnh: có logo thật thì thay `crm/client/public/demo/logo.svg` và `crm/client/src/assets/receipt-logo.svg` sau khi chạy lệnh trên. Thay `cover.svg`, `p1.svg` đến `p6.svg`, hoặc thêm ảnh rồi trỏ `image` trong demo.json tới `/demo/ten-anh`.
5. Trang chủ: `crm/client/src/components/HomeHero.tsx` có tiêu đề, câu phụ và ba thẻ "Sản phẩm / Dịch vụ / Gói combo". Viết lại cho hợp ngành, phần còn lại ở `crm/client/src/pages/Home.tsx`.
6. Tìm chữ ngành mẫu còn sót trong `crm/client/src`: `máy lọc`, `robot`, `lắp đặt`. Thay đúng nghĩa, không thay mù trong mã.

Chỉ đổi demo.json và chạy `--reset` trong lúc còn xem thử. Lệnh `--reset` **xóa toàn bộ dữ liệu trong `crm/.local`**, không chạy khi đã có khách thật.

## Lead Page và Sale Page

- `lead/index.html` là Lead Page, `lead/ban-hang/index.html` là Sale Page, `lead/cam-on/index.html` là trang cảm ơn. Ghi chú KHỐI trong mã nêu công thức từng khối, giữ lại để sau này sửa.
- Sửa chữ, giữ các thuộc tính của form: `id="lead-form"`, `name`, `phone`, `course`, `website`, `consent`, `data-page`.
- Màu: biến đầu tệp `lead/styles.css`, đặt trùng `colors` của CRM. Đổi cả nền tối `--primary-deep` và ô logo `.brand-mark`, đổi chữ cái trong ô logo và trong dòng `icon` ở đầu hai trang.
- Ảnh: thay `lead/assets/hero.jpg`, sửa `alt` cho đúng ảnh mới. Không có ảnh hợp ngành thì tạo ảnh minh họa bằng công cụ sẵn có. Không có công cụ tạo ảnh thì vẽ một tệp SVG đơn giản, không chữ, rồi trỏ `src` ở cả `lead/index.html` và `lead/ban-hang/index.html` về tệp đó, hoặc bỏ thẻ ảnh. Đừng để ảnh máy lọc nước trên trang ngành khác.
- `lead/lead-config.js`: `interests` là danh sách trong ô quan tâm. Giữ `crmEndpoint` khi còn chạy trên máy.

## Ba nơi tên sản phẩm phải trùng nhau

1. `title` trong `crm/database/demo.json`
2. `interests` trong `lead/lead-config.js`
3. `data-default-interest` trên form trong `lead/ban-hang/index.html`, và các dòng gói bán trên Sale Page

## Lệnh hay dùng, chạy trong `crm/`

```sh
node scripts/demo-local.mjs --background          # chạy nền cả CRM và hai trang
node scripts/demo-local.mjs --background --reset  # nạp lại dữ liệu mẫu
node scripts/demo-local.mjs --stop                # tắt
npm run check
npm run test:system
npm run build
```

Trang Lead và Sale là tệp tĩnh, sửa xong tải lại trình duyệt là thấy. Sửa `business.json` hoặc `demo.json` thì tắt rồi chạy lại. Cổng 3000 hoặc 4173 đang bận thì tắt ứng dụng đang dùng cổng, hoặc đổi `LEAD_PORT` cho cổng trang và thêm địa chỉ mới vào `leadOrigins`.

Sau khi đổi tên, một số mã nội bộ vẫn có tiền tố `NOVA-`, ví dụ mã tham chiếu thanh toán, tên tệp xuất. Chúng không ảnh hưởng hoạt động. Chủ muốn đổi thì sửa trước khi có đơn thật, không đổi khi đã có dữ liệu.
