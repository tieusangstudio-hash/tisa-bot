# Xuất bản và nối TISA BOT

Chỉ làm khi anh chị yêu cầu rõ. Đăng công khai, tiêu tiền, nhắn khách đều phải được đồng ý trước.

## Trước khi có dữ liệu thật

- Đổi mật khẩu quản trị. `admin` / `123456` chỉ chạy khi có `DEMO_ADMIN_LOGIN=true`, là biến mà `demo-local` tự bật trên máy. Bản đưa lên mạng không đặt biến này.
- Bỏ "(mẫu)", "(giả định)" và các cam kết chưa chốt. Xóa dòng `<meta name="robots">` ở hai trang.
- Đặt `ownerEmail` thật trong `crm/template/business.json`, dùng thư mục dữ liệu mới, không dùng lại `.local/app.sqlite` của bản xem thử.
- Điền thông tin pháp lý thật. Không gửi `.local/`, `.env`, `crm.env` hay khóa nào vào chat.

## Đưa lên mạng

**CRM:** cần chỗ chạy được backend và cơ sở dữ liệu. Làm theo `crm/docs/DEPLOYMENT.md` (Cloudflare Workers, D1, R2). Mỗi người tự dùng tài khoản của mình. Nếu dùng ChatGPT Sites thì làm trong Codex với toàn bộ thư mục `crm`.

**Lead Page và Sale Page:** là tệp tĩnh, đưa thư mục `lead/` lên Cloudflare Pages hoặc hosting tĩnh bất kỳ.

**Nối form với CRM khi đã có địa chỉ thật:**

1. `crm/template/business.json`: `siteUrl` là địa chỉ CRM, không có dấu `/` cuối. Thêm địa chỉ trang vào `leadOrigins`. Bỏ các địa chỉ localhost.
2. `lead/lead-config.js`: `crmEndpoint` là `<địa chỉ CRM>/api/consultation-leads`.
3. Đưa bản mới lên, gửi thử form trên chính link công khai, xem khách có vào CRM không. Chỉ báo xong sau khi thử.

**Đặt mật khẩu chủ khi đã lên mạng:** đặt `BOOTSTRAP_TOKEN` trên máy chủ, rồi chạy `BOOTSTRAP_TOKEN=... node scripts/sites-bootstrap.mjs <địa chỉ CRM>`. Thêm `--empty` để bắt đầu không có dữ liệu mẫu, `--reset-password` để đổi mật khẩu. Mật khẩu in một lần, nhắc chủ lưu riêng.

## Nối TISA BOT

Khi cài gói bằng nút cài gói của TISA BOT mới có công cụ `crm_*`. Nếu chưa có, hướng dẫn: trang Gói, "Cài từ tệp .zip", chọn tệp ZIP này.

1. Tạo khóa cho bot, chạy trong `crm/`:
   - Trên máy: `BOOTSTRAP_TOKEN=$(cat .local/bootstrap-token) node scripts/sites-bootstrap.mjs http://localhost:3000 --agent-key`
   - Trên mạng: thay bằng token đã đặt và địa chỉ CRM thật.
   Khóa được lưu vào `~/.config/tisa-crm/crm.env`, lệnh không in khóa ra. Không dán khóa vào chat.
2. Gọi công cụ `crm_connect`. Công cụ tự thêm kết nối `tisa-crm` và gọi thử.
3. Gọi `crm_setup_status` để kiểm tra. Thử hỏi: "Tuần này có bao nhiêu khách mới?"

Sau khi nối, TISA BOT đọc được số liệu (`crm_summary`, `crm_lead_stats`, `crm_list_leads`, `crm_list_orders`, `crm_list_customers`), thêm khách, ghi chú, tạo đơn chờ thanh toán, sửa thông tin web và sản phẩm. Đội Quân AI dùng chung kết nối này.

**Tiền:** bot tạo đơn chờ thanh toán. Việc xác nhận đã nhận tiền cần khóa quyền chủ và chủ đồng ý. Không tự đánh dấu đã thu.

## Bật Zalo

Yêu cầu: TISA BOT đã đăng nhập Zalo. Xem `crm_setup_status`.

1. Viết cùng chủ mẫu lời mời kết bạn (tối đa 150 ký tự) và mẫu tin chào. Lưu bằng `crm_zalo_settings`.
2. Mọi tự động mặc định tắt. Chỉ bật từng mục sau khi chủ duyệt mẫu: mời kết bạn, thêm khách từ tin nhắn, tạo đơn.
3. Chạy thử trước: chủ tự điền form bằng số Zalo của mình, rồi gọi `crm_zalo_sync` một lượt và xem kết quả.

Tài khoản Zalo cá nhân có thể bị hạn chế nếu gửi quá nhiều, nói rõ rủi ro này trước khi bật. Khách yêu cầu dừng thì dừng, CRM có ghi trạng thái từ chối nhận tin.
