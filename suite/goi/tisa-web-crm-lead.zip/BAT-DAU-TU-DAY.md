# Bắt đầu từ đây

Bộ này giúp anh chị có **web CRM quản lý khách, Lead Page lấy số điện thoại và Sale Page bán gói chính**, chỉnh theo đúng doanh nghiệp của mình. Bản 2.0.0 có thêm **Data Zalo / FB, quản lý sale (KPI, hoa hồng) và báo cáo**, đồng thời nối được chatbot Fanpage/Zalo để khách tự vào CRM. AI sẽ hỏi từng câu, câu nào chưa có thì giả định để làm demo trước, cập nhật sau.

## Cách cài

Cần Node.js 22.13 trở lên. AI sẽ kiểm tra giúp.

**Cách 1, trong TISA BOT (nên dùng):** mở trang Gói, bấm "Cài từ tệp .zip", chọn tệp ZIP này và xác nhận. Sau đó dán câu lệnh dưới vào khung chat, không cần đính kèm lại tệp. Chỉ cách này có công cụ nối chatbot và Zalo với CRM.

**Cách 2, trong Claude Code hoặc Codex:** gửi tệp ZIP vào khung chat rồi dán câu lệnh dưới. Cách này dựng được web và CRM, phần nối chatbot cần TISA BOT.

## Câu lệnh (copy nguyên khối dán vào khung chat)

```text
Em cài bộ CRM v2 (Web CRM, Lead Page, Sale Page và Data chatbot) giúp anh chị, làm theo skill tisa-web-crm-lead. Nếu có tệp ZIP đính kèm thì giải nén vào một thư mục mới và đọc BAT-DAU-TU-DAY.md trước, không ghi đè dữ liệu cũ. Hỏi anh chị từng câu một, câu nào anh chị chưa có thì em giả định để làm demo trước. Tự kiểm tra máy, dựng web và CRM, rồi hướng dẫn nối chatbot theo references/noi-chatbot-crm.md. Chạy thử 1 lead mẫu, tạo sale thử có KPI và hoa hồng, chốt 1 đơn thử để kiểm tra hoa hồng tự tính, xong thì xóa hết dữ liệu thử. Hỏi anh chị trước khi sửa kịch bản chatbot hoặc đưa web lên mạng. Không in khóa bí mật vào chat. Làm xong cho anh chị xem Lead Page, Sale Page và trang quản trị CRM.
```

## Sẽ có gì sau khi xong

- Lead Page: http://localhost:4173/
- Sale Page: http://localhost:4173/ban-hang/
- CRM: http://localhost:3000/login, tài khoản `admin`, mật khẩu `123456`

Các link này chỉ mở được trên chính máy đang chạy. Tài khoản `admin` / `123456` chỉ để xem thử trên máy, **phải đổi trước khi có dữ liệu thật hoặc đưa lên mạng**. AI sẽ hướng dẫn khi anh chị yêu cầu xuất bản.

Nội dung mẫu về máy lọc nước và tên NOVA là hư cấu. Công thức giúp trang rõ và thuyết phục hơn, còn tỉ lệ chuyển đổi thật phải đo khi có khách vào trang.

## Tính năng bản 2.0.0

- Data Zalo / FB: bảng khách 20 dòng/trang, tìm/lọc, DISC màu, tiềm năng AI 4 mức chỉ xem kèm lý do.
- Hồ sơ có tin nhắn gốc Khách/Page, sale phụ trách và chốt đơn.
- Quản lý sale: KPI tháng, hoa hồng, sửa/hủy đơn tự tính lại.
- Báo cáo chọn thời gian, 6 chỉ số, biểu đồ, bảng ngày/kênh/sale/tiềm năng và xuất CSV.
- Plugin tự đính kèm hội thoại TISA BOT, dùng URL và khóa riêng của học viên.

## Trong bộ có gì

| Nội dung gói | Công dụng |
| --- | --- |
| assets/crm-source.zip | CRM, API chatbot, sale, báo cáo, mã chạy local và hosting |
| assets/lead-source.zip | Lead Page và Sale Page nối form vào CRM |
| connectors/tisa-crm.json | Kết nối MCP đọc/ghi CRM |
| plugins/crm-zalo/ | Nối CRM với Zalo, mọi tự động mặc định tắt |
| plugins/crm-chatbot-leads/ | Đẩy data chatbot, nối và kiểm tra API |
| skills/tisa-web-crm-lead/ | Quy trình hỏi từng câu và các hướng dẫn chi tiết |
| tisa-pack.yaml | Manifest gói chuẩn tisa-pack spec 1, bản 2.0.0 |

Mật khẩu admin/123456 chỉ cho demo local. Đổi mật khẩu trước khách thật. Không chia sẻ chatbot.env, crm.env hoặc thư mục .local.
